"use client";

import * as React from "react";
import { useEffect, useRef } from "react";
import Autoplay from "embla-carousel-autoplay";
import { type CarouselApi } from "@/components/ui/carousel";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { gsap } from "gsap";

const slides = [
  {
    title: "Welcome to Geo-Informatic",
    description:
      "At Geo Informatics Services, we specialize in providing high-quality Geographic Information System (GIS) solutions tailored to meet the evolving needs of modern industries.",
  },
  {
    title: "Professional Approach & Quality Services",
    description:
      "Our team consists of experienced GIS professionals, analysts, and engineers dedicated to delivering reliable, cost-effective, and innovative geospatial solutions.",
  },
  {
    title: "Bringing Your Data to Life",
    description:
      "From mapping and surveying to spatial analysis and data visualization, we bring your data to life through powerful geospatial intelligence.",
  },
];

export default function HeroVideo() {
  const [api, setApi] = React.useState<CarouselApi>();
  const [current, setCurrent] = React.useState(0);
  const [count, setCount] = React.useState(0);
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  React.useEffect(() => {
    if (!api) {
      return;
    }

    setCount(api.scrollSnapList().length);
    setCurrent(api.selectedScrollSnap());

    const onSelect = () => {
      setCurrent(api.selectedScrollSnap());
    };

    api.on("select", onSelect);

    return () => {
      api.off("select", onSelect);
    };
  }, [api]);

  // Add entrance animation
  useEffect(() => {
    if (!sectionRef.current) return;

    const ctx = gsap.context(() => {
      gsap.from(".hero-content", {
        opacity: 0,
        y: 60,
        duration: 1.2,
        ease: "power3.out",
        delay: 0.3,
      });

      gsap.from(".hero-controls", {
        opacity: 0,
        scale: 0.8,
        duration: 0.8,
        ease: "back.out(1.7)",
        delay: 1,
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Try to start video playback programmatically to improve autoplay reliability
  React.useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    // Some browsers block autoplay unless muted; ensure muted is set then call play()
    v.muted = true;
    const p = v.play();
    if (p && typeof p.then === "function") {
      p.catch((err) => {
        // Autoplay prevented; user interaction may be required. Log for debugging.
        // Leave the video element in place so the user can still play it manually.
        // eslint-disable-next-line no-console
        // swallow autoplay errors silently in production — they do not affect layout
        if (process.env.NODE_ENV !== 'production') {
          console.debug("Background video autoplay prevented:", err);
        }
      });
    }
  }, []);

  return (
    <section ref={sectionRef} className="relative h-screen w-full overflow-hidden bg-black">
      {/* Video Background with enhanced overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 z-0">
          <video
            ref={videoRef}
            className="absolute top-1/2 left-1/2 min-w-full min-h-full w-auto h-auto -translate-x-1/2 -translate-y-1/2 scale-105 object-cover"
            src="/bg-1.mp4"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            aria-hidden="true"
          >
            Your browser does not support the video tag.
          </video>
        </div>
        {/* Animated gradient overlay */}
        <div className="absolute inset-0 z-10 bg-gradient-to-b from-black/60 via-black/40 to-black/60 animate-pulse" style={{ animationDuration: '8s' }}></div>
        {/* Radial gradient for vignette effect */}
        <div className="absolute inset-0 z-10 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)] pointer-events-none"></div>
      </div>

      {/* (Removed animated particles/bubbles per request) */}

  <div className="relative z-20 flex h-full flex-col items-center justify-center">
        <Carousel
          setApi={setApi}
          opts={{
            align: "start",
            loop: true,
          }}
          plugins={[
            Autoplay({
              delay: 5000,
              stopOnInteraction: false,
            }),
          ]}
          className="w-full hero-content"
        >
          <CarouselContent>
            {slides.map((slide, index) => (
              <CarouselItem key={index}>
                <div className="flex h-full flex-col items-center justify-center text-center text-white px-4">
                  <div className="container md:px-6 max-w-5xl">
                    <h1 className="text-[42px] sm:text-[52px] md:text-[58px] lg:text-[68px] font-bold leading-[1.1] tracking-[-1px] text-white mb-6 animate-fade-in-up drop-shadow-2xl">
                      {slide.title}
                    </h1>
                    <p className="mx-auto max-w-3xl text-base sm:text-lg md:text-xl text-gray-100 leading-relaxed animate-fade-in-up animate-delay-200 drop-shadow-lg">
                      {slide.description}
                    </p>
                    {/* Decorative line */}
                    <div className="mx-auto mt-8 w-24 h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent animate-pulse" style={{ animationDuration: '3s' }}></div>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          {/* Enhanced navigation arrows */}
          <CarouselPrevious className="hero-controls absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-20 h-12 w-12 md:h-14 md:w-14 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 hover:scale-110 border-0 transition-all duration-300 shadow-xl">
            <ChevronLeft className="h-6 w-6 md:h-7 md:w-7" />
            <span className="sr-only">Previous slide</span>
          </CarouselPrevious>
          <CarouselNext className="hero-controls absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-20 h-12 w-12 md:h-14 md:w-14 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 hover:scale-110 border-0 transition-all duration-300 shadow-xl">
            <ChevronRight className="h-6 w-6 md:h-7 md:w-7" />
            <span className="sr-only">Next slide</span>
          </CarouselNext>
        </Carousel>

        {/* Enhanced pagination dots */}
        <div className="hero-controls absolute bottom-10 z-20 flex justify-center gap-3">
          {Array.from({ length: count }).map((_, index) => (
            <button
              key={index}
              onClick={() => api?.scrollTo(index)}
              className={`rounded-full transition-all duration-500 ${
                current === index 
                  ? "w-10 h-2.5 bg-gradient-to-r from-yellow-400 to-primary shadow-lg shadow-yellow-400/50" 
                  : "w-2.5 h-2.5 bg-white/50 hover:bg-white/80 hover:scale-125"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden md:block" style={{ animationDuration: '2s' }}>
          <div className="w-6 h-10 rounded-full border-2 border-white/40 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-white/60 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
