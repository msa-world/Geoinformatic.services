"use client";

import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

const services = [
  {
    title: "GIS Consultant Services",
    description: "With a team of GIS professionals, surveyors we combine technical precision, on-ground experience and latest geospatial technologies.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-10-3.png",
    link: "/gis-consultant-services"
  },
  {
    title: "Cadastral Mapping Service",
    description: "Implemented through advanced technology like GIS, Geospatial, cadastral mapping enhances precise record-keeping and data accessibility.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png",
    link: "/cadastral-mapping-services"
  },
  {
    title: "Spatial Data Services",
    description: "At geo informatic, our job is to make complex data useful. Our mapping and spatial analysis services are built to support your goals and needs.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-13-5.png",
    link: "/spatial-data-services"
  },
  {
    title: "Topographical Surveying Services",
    description: "We provide Topographical Surveying Services including LIDAR 3D mapping, Building Information Modeling, Revit modeling, 3D laser scanning, 3D imaging etc.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-20-1-6.png",
    link: "/topographical-surveying-services"
  },
  {
    title: "Georeferencing & Digitization Services",
    description: "Stay ahead with accurate, digitised data you can trust. Let us GIS Navigator help you fix gaps, reduce delays, and confidently move your projects forward.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-18-1-7.png",
    link: "/georeferencing-digitization-services"
  },
  {
    title: "Remote Sensing Monitoring Solutions",
    description: "Utilizing advanced remote sensing technologies, we deliver accurate environmental data analysis, land cover mapping, and real-time monitoring.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-19-1-8.png",
    link: "/remote-sensing-monitoring-solutions"
  },
];

const ServicesGrid = () => {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!titleRef.current || !cardsRef.current) return;

    // Text fill animation for title
    const title = titleRef.current;
    const titleText = title.innerHTML;
    const plainText = title.textContent || "";
    
    title.innerHTML = `
      <span style="position: relative; display: inline-block;">
        <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; color: transparent; -webkit-text-stroke: 2px #1A1A1A; opacity: 0.2;">${plainText}</span>
        <span class="text-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, currentColor 0%, currentColor 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${titleText}</span>
      </span>
    `;

    const fillElement = title.querySelector('.text-fill') as HTMLElement;

    gsap.to(fillElement, {
      backgroundPosition: "0% 0",
      ease: "none",
      scrollTrigger: {
        trigger: title,
        start: "top 70%",
        end: "top 30%",
        scrub: 1,
      },
    });

    // Parallax and stagger animation for cards
    const cards = cardsRef.current.querySelectorAll('.service-card');
    
    cards.forEach((card, index) => {
      // Card entrance animation with rotation
      gsap.from(card, {
        y: 100,
        opacity: 0,
        scale: 0.85,
        rotateX: 15,
        duration: 1,
        delay: index * 0.15,
        ease: "power3.out",
        scrollTrigger: {
          trigger: card,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      });

      // Parallax effect on images
      const image = card.querySelector('.service-image');
      if (image) {
        gsap.to(image, {
          y: -40,
          ease: "none",
          scrollTrigger: {
            trigger: card,
            start: "top bottom",
            end: "bottom top",
            scrub: 1,
          },
        });
      }
    });

  }, []);

  return (
    <section className="relative bg-gradient-to-b from-[#D9A561] via-[#C7A24D] to-[#7FA89A] py-20 lg:py-28 overflow-hidden">
      {/* Animated background shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '6s' }} />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '7s', animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '8s', animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <h2 ref={titleRef} className="text-center text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-20">
          Our <span className="text-accent italic">Services</span>
        </h2>
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="service-card group relative bg-white/95 backdrop-blur-sm rounded-2xl overflow-hidden transition-all duration-700 ease-out hover:scale-[1.05] flex flex-col"
              style={{
                boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(199,162,77,0.1)',
              }}
            >
              {/* Glowing border effect */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
                style={{
                  background: 'linear-gradient(135deg, rgba(199,162,77,0.4), rgba(217,125,37,0.4), rgba(176,66,198,0.4))',
                  filter: 'blur(20px)',
                  transform: 'scale(1.05)',
                }}
              />
              
              {/* Card content */}
              <div className="relative z-10 flex flex-col h-full">
                <div className="overflow-hidden relative">
                  {/* Gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-700 z-10 flex flex-col items-center justify-center gap-3">
                    <span className="text-white font-semibold text-xl tracking-wide">View Details</span>
                    <ArrowRight className="w-6 h-6 text-white animate-bounce" />
                  </div>
                  <Image
                    src={service.image}
                    alt={service.title}
                    width={400}
                    height={250}
                    className="service-image w-full h-64 object-cover transition-all duration-700 ease-out group-hover:scale-110 group-hover:brightness-75"
                  />
                </div>
                <div className="p-8 flex-grow flex flex-col bg-gradient-to-b from-white/95 to-white/90 backdrop-blur-sm">
                  <h3 className="text-2xl font-bold text-text-primary mb-4 transition-all duration-500 group-hover:text-primary group-hover:translate-x-1">
                    {service.title}
                  </h3>
                  <p className="text-text-secondary leading-relaxed flex-grow mb-6 transition-all duration-500 group-hover:text-text-primary/80">
                    {service.description}
                  </p>
                  <Link
                    href={service.link}
                    className="mt-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-secondary to-secondary/90 text-white font-semibold py-3.5 px-7 rounded-lg hover:from-secondary/90 hover:to-secondary transition-all duration-500 text-center shadow-lg hover:shadow-2xl hover:shadow-secondary/50 hover:scale-105 group/btn"
                  >
                    <span>Read More</span>
                    <ArrowRight className="w-4 h-4 transition-transform duration-500 group-hover/btn:translate-x-1" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;
