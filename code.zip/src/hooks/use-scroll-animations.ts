"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

export const useScrollAnimations = () => {
  useEffect(() => {
    // Refresh ScrollTrigger on mount
    ScrollTrigger.refresh();

    return () => {
      // Cleanup all ScrollTriggers on unmount
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);
};

export const useTextFillAnimation = (selector: string) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    const elements = ref.current.querySelectorAll(selector);

    elements.forEach((element) => {
      const htmlElement = element as HTMLElement;
      const text = htmlElement.textContent || "";

      // Create the layered text effect
      htmlElement.innerHTML = `
        <span style="position: relative; display: inline-block;">
          <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0.2; color: currentColor;">${text}</span>
          <span class="text-fill-animated" style="position: relative; display: inline-block; background: linear-gradient(to right, currentColor 0%, currentColor 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent;">${text}</span>
        </span>
      `;

      const fillElement = htmlElement.querySelector(".text-fill-animated");

      if (fillElement) {
        gsap.to(fillElement, {
          backgroundPosition: "0% 0",
          ease: "none",
          scrollTrigger: {
            trigger: htmlElement,
            start: "top 75%",
            end: "top 25%",
            scrub: 1,
          },
        });
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => {
        if (elements.length && Array.from(elements).some(el => trigger.trigger === el)) {
          trigger.kill();
        }
      });
    };
  }, [selector]);

  return ref;
};

export const useParallax = (speed: number = 0.5) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    const element = ref.current;

    gsap.to(element, {
      y: () => window.innerHeight * speed,
      ease: "none",
      scrollTrigger: {
        trigger: element,
        start: "top bottom",
        end: "bottom top",
        scrub: true,
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => {
        if (trigger.trigger === element) {
          trigger.kill();
        }
      });
    };
  }, [speed]);

  return ref;
};

export const useFadeIn = (delay: number = 0) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    const element = ref.current;

    gsap.from(element, {
      y: 60,
      opacity: 0,
      duration: 1,
      delay,
      ease: "power3.out",
      scrollTrigger: {
        trigger: element,
        start: "top 85%",
        toggleActions: "play none none none",
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => {
        if (trigger.trigger === element) {
          trigger.kill();
        }
      });
    };
  }, [delay]);

  return ref;
};
