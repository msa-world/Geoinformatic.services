"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { AlertCircle, Trash2, LogOut, Eye, MessageSquare } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

interface UserProfile {
  id: string
  email: string
  full_name: string
  role: string
  phone_number: string
  company: string
  location: string
  created_at: string
}

export default function AdminUsersPage() {
  const router = useRouter()
  const [users, setUsers] = useState<UserProfile[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editData, setEditData] = useState<Partial<UserProfile>>({})

  useEffect(() => {
    const checkAdmin = () => {
      const adminToken = localStorage.getItem("adminToken")
      const adminUsername = localStorage.getItem("adminUsername")

      if (!adminToken || !adminUsername) {
        router.push("/auth/admin-login")
        return
      }

      fetchAllUsers()
    }

    checkAdmin()
  }, [])

  const fetchAllUsers = async () => {
    try {
      setIsLoading(true)
      console.log("[v0] Admin Users Page: Fetching ALL users from profiles table")
      const adminToken = localStorage.getItem("adminToken")
      const response = await fetch("/api/admin/get-users", {
        headers: {
          "x-admin-token": adminToken || "",
        },
      })

      if (!response.ok) {
        throw new Error("Failed to fetch users")
      }

      const { users: data } = await response.json()
      console.log("[v0] Admin Users Page: Total users fetched:", data?.length || 0)
      setUsers(data || [])
      console.log(
        "[v0] Users loaded - IDs:",
        data?.map((u) => u.id),
      )
    } catch (err) {
      console.error("[v0] Error fetching users:", err)
      setError("Failed to load users. This shows ALL registered users in the database.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = (user: UserProfile) => {
    setEditingId(user.id)
    setEditData(user)
  }

  const handleSaveEdit = async () => {
    if (!editingId) return

    try {
      const supabase = createClient()
      const { error: updateError } = await supabase.from("profiles").update(editData).eq("id", editingId)

      if (updateError) throw updateError

      setUsers(users.map((u) => (u.id === editingId ? { ...u, ...editData } : u)))
      setEditingId(null)
      setEditData({})
    } catch (err) {
      console.error("[v0] Error updating user:", err)
      setError("Failed to update user")
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!confirm("Are you sure you want to delete this user account?")) return

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch("/api/admin/delete-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-token": token || "",
        },
        body: JSON.stringify({ userId }),
      })

      if (!response.ok) {
        const data = await response.json()
        setError(data.message || "Failed to delete user")
        return
      }

      setUsers(users.filter((u) => u.id !== userId))
      setError("")
    } catch (err) {
      console.error("[v0] Error deleting user:", err)
      setError("Failed to delete user")
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    localStorage.removeItem("adminUsername")
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center">
        <p className="text-gray-500">Loading users...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen w-full bg-gray-50">
      {/* Admin Navigation Bar */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              <Link href="/admin/dashboard" className="text-lg font-bold text-primary hover:opacity-80">
                Admin Dashboard
              </Link>
              <nav className="hidden md:flex items-center gap-6">
                <Link href="/admin/users" className="font-semibold text-primary border-b-2 border-primary pb-1">
                  User Management
                </Link>
                <Link href="/admin/chat" className="text-muted-foreground hover:text-primary transition-colors">
                  Chat
                </Link>
              </nav>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="gap-2 bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-primary">User Management</h1>
          <p className="text-muted-foreground mt-1">Manage all {users.length} user accounts</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 flex items-start gap-3 p-4 rounded-lg bg-red-50 border border-red-200">
            <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {/* Users Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map((user) => (
            <Card key={user.id} className="shadow-lg hover:shadow-xl transition-shadow overflow-hidden flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    {/* User Avatar */}
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-white flex items-center justify-center text-lg font-bold flex-shrink-0">
                      {user.full_name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm truncate">{user.full_name || "User"}</h3>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 pb-3">
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-muted-foreground text-xs">Role</p>
                    <p className="font-medium">{user.role || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Company</p>
                    <p className="font-medium">{user.company || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Joined</p>
                    <p className="font-medium">{new Date(user.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </CardContent>
              <div className="border-t p-3 flex flex-col sm:flex-row gap-2">
                <Link href={`/admin/user/${user.id}`} className="flex-1">
                  <Button size="sm" variant="outline" className="w-full bg-transparent">
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                </Link>
                <Link href="/admin/chat" className="flex-1">
                  <Button size="sm" variant="outline" className="w-full bg-transparent">
                    <MessageSquare className="h-4 w-4 mr-1" />
                    Chat
                  </Button>
                </Link>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleDeleteUser(user.id)}
                  className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {users.length === 0 && !isLoading && (
          <Card className="flex items-center justify-center py-12">
            <p className="text-muted-foreground">No users found</p>
          </Card>
        )}
      </div>
    </div>
  )
}
