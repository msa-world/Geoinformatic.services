"use client";

import HeaderNavigation from "@/components/sections/header-navigation";
import Footer from "@/components/sections/footer";
import Image from "next/image";
import { MapPin, Calendar, Layers } from "lucide-react";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const projects = [
  {
    title: "Urban Planning & Development Analysis",
    client: "Municipal Planning Authority",
    location: "Rawalpindi, Pakistan",
    date: "2024",
    category: "Urban Planning",
    description: "Comprehensive GIS analysis for urban development planning covering over 500 km² of metropolitan area. Delivered detailed land use mapping, infrastructure analysis, and growth projections.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png",
    features: ["Land Use Classification", "Infrastructure Mapping", "Growth Modeling"]
  },
  {
    title: "AMS Planning Housing Site Analysis",
    client: "Survey of Pakistan",
    location: "Pakistan",
    date: "2023-2024",
    category: "Site Analysis",
    description: "Advanced site suitability analysis for housing development identifying 50+ optimal sites based on 30+ spatial and environmental factors including accessibility, utilities, and terrain.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-1560-x-1440-px-1560-x-740-px-2-scaled-10.png",
    features: ["Multi-Criteria Analysis", "Site Suitability Modeling", "Environmental Assessment"]
  },
  {
    title: "Cadastral Database Modernization",
    client: "Provincial Land Records Authority",
    location: "Punjab, Pakistan",
    date: "2023",
    category: "Cadastral Mapping",
    description: "Complete digitization and georeferencing of 10,000+ land parcels with integrated ownership records and boundary information for improved land administration.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-13-5.png",
    features: ["Digital Cadastre", "Boundary Surveying", "Database Integration"]
  },
  {
    title: "Environmental Monitoring System",
    client: "Environmental Protection Agency",
    location: "Multiple Regions",
    date: "2022-2024",
    category: "Remote Sensing",
    description: "Satellite-based environmental monitoring system for tracking deforestation, land cover changes, and vegetation health across 5,000+ km² using multi-temporal remote sensing data.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-19-1-8.png",
    features: ["Change Detection", "Vegetation Indices", "Automated Reporting"]
  },
  {
    title: "Infrastructure Asset Management",
    client: "Metropolitan Development Authority",
    location: "Islamabad, Pakistan",
    date: "2023",
    category: "Asset Management",
    description: "Complete 3D mapping and inventory of urban infrastructure including roads, utilities, and public facilities using LIDAR and high-resolution imagery.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-20-1-6.png",
    features: ["3D Asset Mapping", "LIDAR Processing", "Maintenance Scheduling"]
  },
  {
    title: "Agricultural Land Assessment",
    client: "Agricultural Development Board",
    location: "Rural Districts",
    date: "2022",
    category: "Agriculture",
    description: "Comprehensive agricultural land capability assessment using remote sensing, soil data, and topographic analysis for optimal crop planning.",
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-10-3.png",
    features: ["Soil Analysis", "Crop Suitability", "Irrigation Planning"]
  },
];

export default function ProjectsPage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRefs = useRef<(HTMLHeadingElement | null)[]>([]);
  const imageRefs = useRef<(HTMLDivElement | null)[]>([]);
  const contentRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    // Hero text fill animation
    if (heroRef.current) {
      const heroTitle = heroRef.current.querySelector("h1");
      const heroSubtitle = heroRef.current.querySelector("p");

      if (heroTitle) {
        const text = heroTitle.textContent || "";
        heroTitle.innerHTML = `
          <span style="position: relative; display: inline-block;">
            <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0.15; color: white;">${text}</span>
            <span class="hero-text-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, white 0%, white 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${text}</span>
          </span>
        `;

        gsap.to(".hero-text-fill", {
          backgroundPosition: "0% 0",
          duration: 2,
          ease: "power2.out",
          delay: 0.3,
        });
      }

      if (heroSubtitle) {
        gsap.from(heroSubtitle, {
          y: 30,
          opacity: 0,
          duration: 1,
          delay: 0.8,
          ease: "power3.out",
        });
      }
    }

    // Project titles text fill animation
    titleRefs.current.forEach((title, index) => {
      if (!title) return;

      const text = title.textContent || "";
      title.innerHTML = `
        <span style="position: relative; display: inline-block;">
          <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0.1; color: currentColor;">${text}</span>
          <span class="project-title-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, currentColor 0%, currentColor 50%, rgba(102,102,102,0.3) 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${text}</span>
        </span>
      `;

      const fillElement = title.querySelector(".project-title-fill");

      if (fillElement) {
        gsap.to(fillElement, {
          backgroundPosition: "0% 0",
          ease: "none",
          scrollTrigger: {
            trigger: title,
            start: "top 80%",
            end: "top 30%",
            scrub: 1,
          },
        });
      }
    });

    // Parallax effect on images
    imageRefs.current.forEach((imageContainer) => {
      if (!imageContainer) return;

      const image = imageContainer.querySelector("img");
      if (image) {
        gsap.to(image, {
          y: -50,
          ease: "none",
          scrollTrigger: {
            trigger: imageContainer,
            start: "top bottom",
            end: "bottom top",
            scrub: 1,
          },
        });
      }
    });

    // Content fade and slide animations
    contentRefs.current.forEach((content, index) => {
      if (!content) return;

      gsap.from(content, {
        y: 80,
        opacity: 0,
        duration: 1.2,
        ease: "power3.out",
        scrollTrigger: {
          trigger: content,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      });

      // Stagger animation for features
      const features = content.querySelectorAll(".feature-tag");
      if (features.length > 0) {
        gsap.from(features, {
          scale: 0.8,
          opacity: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: content,
            start: "top 75%",
            toggleActions: "play none none none",
          },
        });
      }
    });

    // CTA section animation
    const ctaSection = document.querySelector(".cta-section");
    if (ctaSection) {
      gsap.from(ctaSection, {
        scale: 0.95,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: ctaSection,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        {/* Hero Section with Parallax */}
        <section 
          ref={heroRef}
          className="relative bg-gradient-to-br from-[#C7A24D] via-[#D97D25] to-[#7FA89A] py-24 lg:py-32 overflow-hidden"
        >
          {/* Animated background shapes */}
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="absolute top-20 left-10 w-72 h-72 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }}></div>
          
          <div className="container relative mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Our Projects
            </h1>
            <p className="text-xl md:text-2xl text-white/95 max-w-3xl mx-auto">
              Explore our portfolio of successful GIS projects delivering impactful solutions across diverse industries
            </p>
          </div>
        </section>

        {/* Projects Grid with Advanced Animations */}
        <section className="bg-white py-20 lg:py-24 relative overflow-hidden">
          {/* Subtle background pattern */}
          <div className="absolute inset-0 opacity-[0.02]" style={{
            backgroundImage: "radial-gradient(circle, #C7A24D 1px, transparent 1px)",
            backgroundSize: "50px 50px"
          }}></div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="grid gap-20 lg:gap-32">
              {projects.map((project, index) => (
                <div
                  key={index}
                  className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
                    index % 2 === 1 ? "lg:flex-row-reverse" : ""
                  }`}
                >
                  {/* Image with Parallax */}
                  <div className={index % 2 === 1 ? "lg:order-2" : ""}>
                    <div 
                      ref={(el) => { imageRefs.current[index] = el; }}
                      className="relative h-[350px] lg:h-[450px] rounded-2xl overflow-hidden shadow-2xl group"
                      style={{
                        background: "linear-gradient(135deg, rgba(199,162,77,0.1) 0%, rgba(217,125,37,0.1) 100%)"
                      }}
                    >
                      <Image
                        src={project.image}
                        alt={project.title}
                        fill
                        className="object-cover transition-all duration-700 group-hover:scale-110"
                        style={{ transformOrigin: "center center" }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      
                      {/* Glass overlay on hover */}
                      <div className="absolute inset-0 bg-white/10 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
                        <div className="text-white text-center p-6">
                          <p className="text-lg font-semibold">View Project Details</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Content with Fade In Animation */}
                  <div 
                    ref={(el) => { contentRefs.current[index] = el; }}
                    className={index % 2 === 1 ? "lg:order-1" : ""}
                  >
                    <div className="inline-block bg-gradient-to-r from-primary/20 to-secondary/20 backdrop-blur-sm text-primary px-5 py-2.5 rounded-full text-sm font-semibold mb-5 border border-primary/20">
                      {project.category}
                    </div>
                    
                    <h2 
                      ref={(el) => { titleRefs.current[index] = el; }}
                      className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary mb-6 leading-tight"
                    >
                      {project.title}
                    </h2>
                    
                    <div className="flex flex-wrap gap-4 mb-6 text-text-secondary">
                      <div className="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-lg">
                        <MapPin className="w-5 h-5 text-primary" />
                        <span>{project.location}</span>
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-lg">
                        <Calendar className="w-5 h-5 text-primary" />
                        <span>{project.date}</span>
                      </div>
                    </div>

                    <p className="text-lg text-text-secondary leading-relaxed mb-8">
                      {project.description}
                    </p>

                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-semibold text-text-primary">
                        <Layers className="w-5 h-5 text-primary" />
                        <span>Key Features:</span>
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {project.features.map((feature, fIndex) => (
                          <span
                            key={fIndex}
                            className="feature-tag bg-gradient-to-br from-gray-50 to-gray-100 text-text-secondary px-5 py-2.5 rounded-xl text-sm font-medium border border-gray-200 hover:border-primary/50 hover:shadow-md transition-all duration-300"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>

                    {project.client && (
                      <div className="mt-8 pt-6 border-t border-gray-200">
                        <p className="text-sm text-text-secondary">
                          <span className="font-semibold text-text-primary">Client:</span> {project.client}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section with Glass Effect */}
        <section className="cta-section relative bg-gradient-to-r from-[#D9A561] to-[#7FA89A] py-24 overflow-hidden">
          {/* Glassmorphism overlay */}
          <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
          
          {/* Animated shapes */}
          <div className="absolute top-10 left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1.5s" }}></div>
          
          <div className="container relative mx-auto px-4 text-center z-10">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              Ready to Start Your GIS Project?
            </h2>
            <p className="text-xl text-white/95 mb-10 max-w-2xl mx-auto leading-relaxed">
              Let's work together to bring your geospatial vision to life with our expert team and proven methodologies.
            </p>
            <a
              href="/contact"
              className="inline-block bg-white/95 backdrop-blur-md text-primary font-semibold px-12 py-5 rounded-full hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:bg-white border-2 border-white/50"
            >
              Get Started
            </a>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
