"use client";

import * as React from "react";
import { useEffect, useRef } from "react";
import Autoplay from "embla-carousel-autoplay";
import { type CarouselApi } from "@/components/ui/carousel";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { gsap } from "gsap";
import Link from "next/link";
import { Button } from "@/components/ui/button";

const slides = [
  {
    title: "Welcome to Geo-Informatic",
    description:
      "At Geo Informatics Services, we specialize in providing high-quality Geographic Information System (GIS) solutions tailored to meet the evolving needs of modern industries.",
  },
  {
    title: "Professional Approach & Quality Services",
    description:
      "Our team consists of experienced GIS professionals, analysts, and engineers dedicated to delivering reliable, cost-effective, and innovative geospatial solutions.",
  },
  {
    title: "Bringing Your Data to Life",
    description:
      "From mapping and surveying to spatial analysis and data visualization, we bring your data to life through powerful geospatial intelligence.",
  },
];

export default function HeroVideo() {
  const [api, setApi] = React.useState<CarouselApi>();
  const [current, setCurrent] = React.useState(0);
  const [count, setCount] = React.useState(0);
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  React.useEffect(() => {
    if (!api) {
      return;
    }

    setCount(api.scrollSnapList().length);
    setCurrent(api.selectedScrollSnap());

    const onSelect = () => {
      setCurrent(api.selectedScrollSnap());
    };

    api.on("select", onSelect);

    return () => {
      api.off("select", onSelect);
    };
  }, [api]);

  // Enhanced entrance animation using a GSAP timeline
  useEffect(() => {
    if (!sectionRef.current) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

      // gentle video zoom for depth
      tl.from(videoRef.current, { scale: 1.08, duration: 1.8, ease: "power2.out" }, 0);

      // headline and description stagger with improved timing
      tl.from(
        ".hero-title",
        { y: 50, opacity: 0, duration: 1.1, ease: "power4.out" },
        0.2
      );

      tl.from(
        ".hero-desc",
        { y: 25, opacity: 0, duration: 0.9, ease: "power3.out" },
        0.5
      );

      // Decorative line animation
      tl.from(
        ".hero-cta",
        { y: 30, opacity: 0, duration: 0.8, ease: "back.out(1.3)" },
        0.8
      );

      // CTAs appear with smooth stagger
      tl.from(
        ".hero-cta button",
        { y: 15, opacity: 0, scale: 0.95, stagger: 0.15, duration: 0.7, ease: "back.out(1.5)" },
        0.95
      );

      // navigation controls
      tl.from(
        ".hero-controls",
        { scale: 0.85, opacity: 0, duration: 0.8, ease: "back.out(1.4)" },
        1.3
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Try to start video playback programmatically to improve autoplay reliability
  React.useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    // Some browsers block autoplay unless muted; ensure muted is set then call play()
    v.muted = true;
    const p = v.play();
    if (p && typeof p.then === "function") {
      p.catch((err) => {
        // Autoplay prevented; user interaction may be required. Log for debugging.
        // Leave the video element in place so the user can still play it manually.
        // eslint-disable-next-line no-console
        // swallow autoplay errors silently in production — they do not affect layout
        if (process.env.NODE_ENV !== 'production') {
          console.debug("Background video autoplay prevented:", err);
        }
      });
    }
  }, []);

  return (
    <section ref={sectionRef} className="relative h-screen w-full overflow-hidden bg-black">
      {/* Video Background with enhanced overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 z-0">
          <video
            ref={videoRef}
            className="absolute top-1/2 left-1/2 min-w-full min-h-full w-auto h-auto -translate-x-1/2 -translate-y-1/2 scale-105 object-cover"
            src="/bg-1.mp4"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            aria-hidden="true"
          >
            Your browser does not support the video tag.
          </video>
        </div>
  {/* Animated gradient overlay */}
  <div className="absolute inset-0 z-10 bg-gradient-to-b from-black/60 via-black/40 to-black/60 animate-pulse"></div>
        {/* Radial gradient for vignette effect */}
        <div className="absolute inset-0 z-10 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)] pointer-events-none"></div>
      </div>

      {/* (Removed animated particles/bubbles per request) */}

  <div className="relative z-20 flex h-full flex-col items-center justify-center">
        <Carousel
          setApi={setApi}
          opts={{
            align: "start",
            loop: true,
          }}
          plugins={[
            Autoplay({
              delay: 5000,
              stopOnInteraction: false,
            }),
          ]}
          className="w-full hero-content"
        >
          <CarouselContent>
            {slides.map((slide, index) => (
              <CarouselItem key={index}>
                <div className="flex h-full flex-col items-center justify-center text-center text-white px-4 py-8">
                  <div className="container md:px-6 max-w-6xl">
                    <h1 className="hero-title text-[42px] sm:text-[52px] md:text-[62px] lg:text-[72px] font-black leading-[1.05] tracking-tighter text-white mb-6 drop-shadow-2xl">
                      {slide.title}
                    </h1>
                    <p className="hero-desc mx-auto max-w-3xl text-base sm:text-lg md:text-xl lg:text-2xl text-gray-200 leading-relaxed drop-shadow-lg font-light">
                      {slide.description}
                    </p>
                    {/* Decorative line with glow */}
                    <div className="flex justify-center mt-10 mb-10">
                      <div className="relative w-32">
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400 to-transparent blur-lg opacity-60"></div>
                        <div className="h-1.5 bg-gradient-to-r from-transparent via-yellow-300 to-transparent animate-pulse rounded-full"></div>
                      </div>
                    </div>

                    {/* CTA buttons */}
                    <div className="mt-10 flex items-center justify-center gap-4 flex-wrap hero-cta">
                      <Link href="/projects" className="inline-block">
                        <Button className="relative px-8 py-3 bg-gradient-to-r from-yellow-400 via-yellow-500 to-orange-500 text-black font-semibold rounded-lg shadow-lg hover:shadow-xl hover:shadow-yellow-500/50 hover:scale-105 transition-all duration-300 overflow-hidden group">
                          <span className="relative z-10">Get Started</span>
                          <div className="absolute inset-0 bg-gradient-to-r from-yellow-300 to-orange-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </Button>
                      </Link>
                      <Link href="/profile/drive" className="inline-block">
                        <Button className="relative px-8 py-3 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl hover:shadow-cyan-500/50 hover:scale-105 transition-all duration-300 overflow-hidden group border border-cyan-400/30">
                          <span className="relative z-10">Connect Drive</span>
                          <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          {/* Enhanced navigation arrows */}
          <CarouselPrevious className="hero-controls absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-20 h-12 w-12 md:h-14 md:w-14 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 hover:scale-110 border-0 transition-all duration-300 shadow-xl">
            <ChevronLeft className="h-6 w-6 md:h-7 md:w-7" />
            <span className="sr-only">Previous slide</span>
          </CarouselPrevious>
          <CarouselNext className="hero-controls absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-20 h-12 w-12 md:h-14 md:w-14 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 hover:scale-110 border-0 transition-all duration-300 shadow-xl">
            <ChevronRight className="h-6 w-6 md:h-7 md:w-7" />
            <span className="sr-only">Next slide</span>
          </CarouselNext>
        </Carousel>

        {/* Enhanced pagination dots */}
        <div className="hero-controls absolute bottom-10 z-20 flex justify-center gap-3">
          {Array.from({ length: count }).map((_, index) => (
            <button
              key={index}
              onClick={() => api?.scrollTo(index)}
              className={`rounded-full transition-all duration-500 ${
                current === index 
                  ? "w-10 h-2.5 bg-gradient-to-r from-yellow-400 to-primary shadow-lg shadow-yellow-400/50" 
                  : "w-2.5 h-2.5 bg-white/50 hover:bg-white/80 hover:scale-125"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

  {/* Scroll indicator */}
  <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
          <div className="w-6 h-10 rounded-full border-2 border-white/40 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-white/60 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
