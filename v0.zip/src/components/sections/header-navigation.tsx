"use client"

import * as React from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"

import { cn } from "@/lib/utils"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { Sheet, SheetContent, SheetHeader, SheetTrigger } from "@/components/ui/sheet"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import UserMenu from "./user-menu"

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/projects", label: "Projects" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
]

const gisServices = [
  { href: "/gis-consultant-services", label: "GIS Consultant Services" },
  { href: "/cadastral-mapping-services", label: "Cadastral Mapping Services" },
  { href: "/spatial-data-services", label: "Spatial Data Services" },
  { href: "/topographical-surveying-services", label: "Topographical Surveying Services" },
  { href: "/georeferencing-digitization-services", label: "Georeferencing & Digitization Services" },
  { href: "/remote-sensing-monitoring-solutions", label: "Remote Sensing Monitoring Solutions" },
  { href: "/web", label: "Web GIS" },
]

export default function HeaderNavigation() {
  const [isScrolled, setIsScrolled] = React.useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false)
  const pathname = usePathname()

  const [user, setUser] = useState<{ id: string; email: string; name?: string } | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const checkUser = async () => {
      try {
        const supabase = createClient()
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (authUser) {
          setUser({
            id: authUser.id,
            email: authUser.email || "",
            name: authUser.user_metadata?.full_name,
          })
        }
      } catch (error) {
        console.error("[v0] Error fetching user:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkUser()
  }, [])

  const closeMobileMenu = () => setIsMobileMenuOpen(false)

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-500",
        isScrolled
          ? "bg-white/80 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.12)] border-b border-white/20"
          : "bg-white/95 backdrop-blur-sm",
      )}
    >
      <div className="container mx-auto flex h-[100px] items-center justify-between px-4 md:px-8 lg:px-10">
        <div className="flex-shrink-0">
          <Link href="/" className="block transition-opacity hover:opacity-80 hover:scale-105 duration-300">
            <Image
              src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/download-15-1.png"
              alt="Geo Informatic Services Logo"
              width={254}
              height={54}
              priority
            />
          </Link>
        </div>

        <nav className="hidden lg:flex lg:items-center lg:justify-center flex-1">
          <NavigationMenu>
            <NavigationMenuList className="gap-x-8">
              <NavigationMenuItem>
                <Link href="/" legacyBehavior passHref>
                  <NavigationMenuLink
                    className={cn(
                      "group relative inline-flex items-center bg-transparent px-0 text-[15px] font-medium transition-colors hover:bg-transparent focus:bg-transparent",
                      pathname === "/" ? "text-primary" : "text-text-primary hover:text-primary",
                    )}
                  >
                    <span className="relative py-2">
                      Home
                      <span
                        className={cn(
                          "absolute bottom-0 left-0 h-[2px] w-full bg-primary transition-transform duration-300 ease-out origin-left",
                          pathname === "/" ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                        )}
                      ></span>
                    </span>
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>

              <NavigationMenuItem>
                <NavigationMenuTrigger
                  className={cn(
                    "group relative bg-transparent px-0 text-[15px] font-medium transition-colors hover:bg-transparent focus:bg-transparent data-[state=open]:bg-transparent",
                    "text-text-primary hover:text-primary data-[state=open]:text-primary",
                  )}
                >
                  Gis Service
                  <span className="absolute bottom-0 left-0 h-[2px] w-full bg-primary scale-x-0 group-hover:scale-x-100 group-data-[state=open]:scale-x-100 transition-transform duration-300 ease-out origin-left"></span>
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="w-[320px] p-2">
                    {gisServices.map((service) => (
                      <li key={service.label}>
                        <Link href={service.href} legacyBehavior passHref>
                          <NavigationMenuLink className="block select-none rounded-md p-3 text-sm leading-relaxed text-text-secondary no-underline outline-none transition-all hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 hover:text-primary hover:translate-x-1">
                            {service.label}
                          </NavigationMenuLink>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>

              {navLinks
                .filter((l) => l.label !== "Home")
                .map((link) => (
                  <NavigationMenuItem key={link.label}>
                    <Link href={link.href} legacyBehavior passHref>
                      <NavigationMenuLink
                        className={cn(
                          "group relative inline-flex items-center bg-transparent px-0 text-[15px] font-medium transition-colors hover:bg-transparent focus:bg-transparent",
                          pathname === link.href ? "text-primary" : "text-text-primary hover:text-primary",
                        )}
                      >
                        <span className="relative py-2">
                          {link.label}
                          <span
                            className={cn(
                              "absolute bottom-0 left-0 h-[2px] w-full bg-primary transition-transform duration-300 ease-out origin-left",
                              pathname === link.href ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                            )}
                          ></span>
                        </span>
                      </NavigationMenuLink>
                    </Link>
                  </NavigationMenuItem>
                ))}
            </NavigationMenuList>
          </NavigationMenu>
        </nav>

        <div className="flex items-center gap-4">
          {!isLoading && user ? (
            <UserMenu user={user} />
          ) : (
            <>
              <Link
                href="/auth/login"
                className="hidden lg:block text-sm font-semibold text-text-primary hover:text-primary transition-colors"
              >
                Sign In
              </Link>
              <Link
                href="/auth/sign-up"
                className="hidden lg:block relative bg-gradient-to-r from-[#C7A24D] to-[#D97D25] text-white font-semibold text-base px-[35px] py-[15px] rounded-full transition-all hover:shadow-[0_8px_32px_rgba(199,162,77,0.4)] hover:scale-105 active:scale-95 overflow-hidden group"
              >
                <span className="relative z-10">Get Started</span>
                <span className="absolute inset-0 bg-gradient-to-r from-[#D97D25] to-[#C7A24D] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
              </Link>
            </>
          )}

          <div className="lg:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Open menu"
                  className="hover:bg-primary/10 transition-colors"
                >
                  <Menu className="h-7 w-7 text-text-primary" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[320px] p-0">
                <SheetHeader className="p-4 border-b">
                  <div className="flex-shrink-0">
                    <Link href="/" onClick={closeMobileMenu}>
                      <Image
                        src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/download-15-1.png"
                        alt="Geo Informatic Services Logo"
                        width={200}
                        height={43}
                      />
                    </Link>
                  </div>
                </SheetHeader>
                <div className="py-4 px-2">
                  <Link
                    href="/"
                    className="block py-3 px-4 rounded font-medium hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 transition-all"
                    onClick={closeMobileMenu}
                  >
                    Home
                  </Link>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1" className="border-b-0">
                      <AccordionTrigger className="py-3 px-4 font-medium hover:no-underline hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 rounded transition-all [&[data-state=open]>svg]:rotate-180">
                        Gis Service
                      </AccordionTrigger>
                      <AccordionContent className="pb-0">
                        <div className="pl-4">
                          {gisServices.map((service) => (
                            <Link
                              key={service.label}
                              href={service.href}
                              className="block py-2.5 px-4 rounded text-muted-foreground hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 hover:text-primary transition-all"
                              onClick={closeMobileMenu}
                            >
                              {service.label}
                            </Link>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                  {navLinks
                    .filter((l) => l.label !== "Home")
                    .map((link) => (
                      <Link
                        key={link.label}
                        href={link.href}
                        className="block py-3 px-4 rounded font-medium hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 transition-all"
                        onClick={closeMobileMenu}
                      >
                        {link.label}
                      </Link>
                    ))}
                  <div className="px-4 pt-6 space-y-2">
                    {!isLoading && user ? (
                      <>
                        <Link
                          href="/profile"
                          className="block text-center w-full border-2 border-primary text-primary font-semibold text-base py-2.5 rounded-full transition-all hover:bg-primary/10"
                          onClick={closeMobileMenu}
                        >
                          Profile
                        </Link>
                        <Link
                          href="/profile/chat"
                          className="block text-center w-full border-2 border-primary text-primary font-semibold text-base py-2.5 rounded-full transition-all hover:bg-primary/10"
                          onClick={closeMobileMenu}
                        >
                          Chat
                        </Link>
                      </>
                    ) : (
                      <>
                        <Link
                          href="/auth/login"
                          className="block text-center w-full border-2 border-primary text-primary font-semibold text-base py-2.5 rounded-full transition-all hover:bg-primary/10"
                          onClick={closeMobileMenu}
                        >
                          Sign In
                        </Link>
                        <Link
                          href="/auth/sign-up"
                          className="block text-center w-full bg-gradient-to-r from-[#C7A24D] to-[#D97D25] text-white font-semibold text-base py-2.5 rounded-full transition-all hover:shadow-lg hover:scale-105 active:scale-95"
                          onClick={closeMobileMenu}
                        >
                          Get Started
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
