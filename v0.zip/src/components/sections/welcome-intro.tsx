"use client"

import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

export default function WelcomeIntro() {
  const titleRef = useRef<HTMLDivElement>(null)
  const paragraphsRef = useRef<HTMLDivElement>(null)
  const buttonsRef = useRef<HTMLDivElement>(null)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (!titleRef.current || !paragraphsRef.current || !buttonsRef.current) return

    const titleContainer = titleRef.current
    const title = titleContainer.querySelector("h2")
    if (!title) return

    const text = title.textContent || ""

    // Create a wrapper for the text fill effect
    title.innerHTML = `<span class="text-fill-wrapper">${text}</span>`
    const fillSpan = title.querySelector(".text-fill-wrapper") as HTMLElement

    if (fillSpan) {
      fillSpan.style.cssText = `
        display: inline-block;
        position: relative;
        background: linear-gradient(to right, #07223F 0%, #07223F 50%, transparent 50%);
        background-size: 200% 100%;
        background-position: 100% 0;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      `

      gsap.to(fillSpan, {
        backgroundPosition: "0% 0",
        ease: "none",
        scrollTrigger: {
          trigger: title,
          start: "top 70%",
          end: "top 30%",
          scrub: 1,
        },
      })
    }

    // Paragraphs fade in with stagger and slide from different directions
    const paragraphs = paragraphsRef.current.querySelectorAll("p")
    paragraphs.forEach((p, index) => {
      gsap.from(p, {
        x: index % 2 === 0 ? -60 : 60,
        y: 40,
        opacity: 0,
        duration: 1,
        delay: index * 0.2,
        ease: "power3.out",
        scrollTrigger: {
          trigger: p,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      })
    })

    // Buttons scale in with bounce
    const buttons = buttonsRef.current.children
    Array.from(buttons).forEach((btn, index) => {
      gsap.from(btn, {
        scale: 0.5,
        opacity: 0,
        rotation: index === 0 ? -10 : 10,
        duration: 0.8,
        delay: 0.8 + index * 0.15,
        ease: "elastic.out(1, 0.6)",
        scrollTrigger: {
          trigger: buttonsRef.current,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      })
    })

    // Section parallax background
    if (sectionRef.current) {
      const bgShapes = sectionRef.current.querySelectorAll(".bg-shape")
      bgShapes.forEach((shape, index) => {
        gsap.to(shape, {
          y: index % 2 === 0 ? -50 : 50,
          ease: "none",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top bottom",
            end: "bottom top",
            scrub: 1,
          },
        })
      })
    }

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [])

  return (
    <section
      ref={sectionRef}
      className="bg-gradient-to-b from-white via-gray-50/30 to-white pt-[100px] pb-24 md:pt-28 md:pb-28 relative overflow-hidden"
    >
      {/* Animated background shapes with parallax */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="bg-shape absolute top-20 right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: "4s" }}
        />
        <div
          className="bg-shape absolute bottom-20 left-10 w-48 h-48 bg-secondary/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: "5s", animationDelay: "1s" }}
        />
        <div
          className="bg-shape absolute top-1/2 right-1/4 w-36 h-36 bg-accent/8 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: "6s", animationDelay: "2s" }}
        />
      </div>

      <div className="container mx-auto flex max-w-[1000px] flex-col items-center px-4 text-center relative z-10">
        <div ref={titleRef} className="mb-8 w-full">
          <h2 className="text-4xl font-bold leading-tight text-[#07223F] md:text-5xl lg:text-6xl">
            Welcome to Geo-Informatic
          </h2>
        </div>
        <div ref={paragraphsRef} className="mb-10 max-w-4xl space-y-6 text-lg leading-[1.8] text-[#666666]">
          <p className="hover:text-[#1A1A1A] transition-colors duration-300">
            At <strong className="text-primary">Geo Informatics Services</strong>, we specialize in providing
            high-quality Geographic Information System (GIS) solutions tailored to meet the evolving needs of modern
            industries.
          </p>
          <p className="hover:text-[#1A1A1A] transition-colors duration-300">
            Our team consists of experienced GIS professionals, analysts, and engineers dedicated to delivering
            reliable, cost-effective, and innovative geospatial solutions.
          </p>
          <p className="hover:text-[#1A1A1A] transition-colors duration-300">
            From mapping and surveying to spatial analysis and data visualization, we bring your data to life through
            powerful geospatial intelligence.
          </p>
        </div>
        <div ref={buttonsRef} className="flex flex-col items-center justify-center gap-6 sm:flex-row sm:gap-8">
          <Link
            href="/contact"
            className="group relative rounded-lg bg-gradient-to-r from-[#1ABC9C] to-[#16a085] px-10 py-4 font-semibold text-white transition-all duration-500 ease-out overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-[#1ABC9C]/40 hover:scale-110"
          >
            {/* Glowing effect */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
              style={{
                background: "radial-gradient(circle at center, rgba(26,188,156,0.4), transparent)",
                filter: "blur(15px)",
              }}
            />
            <span className="relative z-10 flex items-center gap-2">
              Contact US
              <ArrowRight className="w-5 h-5 transition-transform duration-500 group-hover:translate-x-1" />
            </span>
          </Link>
          <Link
            href="/projects"
            className="group flex items-center gap-2 font-bold text-[#07223F] transition-all duration-500 hover:text-[#1ABC9C] hover:gap-4 relative"
          >
            <span className="relative">
              Our Project
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#1ABC9C] to-[#C7A24D] group-hover:w-full transition-all duration-500" />
            </span>
            <ArrowRight className="h-5 w-5 transition-transform duration-500 group-hover:rotate-45" />
          </Link>
        </div>
      </div>
    </section>
  )
}
