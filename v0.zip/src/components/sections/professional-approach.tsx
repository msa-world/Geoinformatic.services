"use client";

import Image from "next/image";
import { useEffect, useRef } from "react";
import { Check } from "lucide-react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const ProfessionalApproach = () => {
    const titleRef = useRef<HTMLHeadingElement>(null);
    const listRef = useRef<HTMLUListElement>(null);
    const imageRef = useRef<HTMLDivElement>(null);
    const sectionRef = useRef<HTMLElement>(null);

    const listItems = [
        "10 + projects",
        "5+ years of commercial experience",
        "15 + satisfied customers",
        "5000 K+ km² worked out and analyzed",
    ];

    useEffect(() => {
        if (!titleRef.current || !listRef.current || !imageRef.current) return;

        // Text fill animation for title
        const title = titleRef.current;
        const text = title.textContent || "";
        title.innerHTML = `
          <span style="position: relative; display: inline-block;">
            <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; color: transparent; -webkit-text-stroke: 2px #1A1A1A; opacity: 0.2;">${text}</span>
            <span class="text-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, #1A1A1A 0%, #1A1A1A 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${text}</span>
          </span>
        `;

        const fillElement = title.querySelector('.text-fill') as HTMLElement;

        gsap.to(fillElement, {
            backgroundPosition: "0% 0",
            ease: "none",
            scrollTrigger: {
                trigger: title,
                start: "top 70%",
                end: "top 30%",
                scrub: 1,
            },
        });

        // List items stagger animation with rotation
        const items = listRef.current.querySelectorAll('li');
        items.forEach((item, index) => {
            gsap.from(item, {
                x: -80,
                opacity: 0,
                rotateY: -20,
                duration: 0.8,
                delay: index * 0.15,
                ease: "power3.out",
                scrollTrigger: {
                    trigger: item,
                    start: "top 85%",
                    toggleActions: "play none none none",
                },
            });
        });

        // Image parallax with scale
        const image = imageRef.current.querySelector('img');
        if (image) {
            gsap.to(image, {
                y: -50,
                scale: 1.1,
                ease: "none",
                scrollTrigger: {
                    trigger: imageRef.current,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 1,
                },
            });
        }

        // Image container entrance animation
        gsap.from(imageRef.current, {
            x: 100,
            opacity: 0,
            scale: 0.9,
            duration: 1.2,
            ease: "power3.out",
            scrollTrigger: {
                trigger: imageRef.current,
                start: "top 80%",
                toggleActions: "play none none none",
            },
        });

    }, []);

    return (
        <section ref={sectionRef} className="bg-gradient-to-b from-white to-gray-50/50 py-20 lg:py-28 relative overflow-hidden">
            {/* Background decoration with parallax */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-1/4 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '7s' }} />
                <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-secondary/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '8s', animationDelay: '1s' }} />
                <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '9s', animationDelay: '2s' }} />
            </div>

            <div className="container relative z-10">
                <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
                    {/* Left Column: Text Content */}
                    <div className="lg:w-1/2 w-full">
                        <h2 ref={titleRef} className="text-4xl lg:text-5xl xl:text-6xl font-bold text-text-primary !leading-tight mb-6">
                            Looking For Professional Approach And Quality Services?
                        </h2>
                        <p className="text-lg text-text-secondary leading-relaxed mb-4">
                            Our experts are ready to guide you in finding the perfect GIS solutions for your needs. Let's discuss your project today!
                        </p>
                        <div className="w-24 h-1 bg-gradient-to-r from-primary via-secondary to-accent mb-8 rounded-full" />
                        <ul ref={listRef} className="space-y-5">
                            {listItems.map((item, index) => (
                                <li key={index} className="group flex items-center relative">
                                    {/* Glowing background on hover */}
                                    <div className="absolute inset-0 -left-4 -right-4 bg-gradient-to-r from-primary/5 via-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 rounded-lg" />
                                    
                                    <div className="relative flex items-center">
                                        <div className="flex-shrink-0 mr-4 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 group-hover:from-primary/40 group-hover:to-secondary/40 transition-all duration-500 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/30">
                                            <Check className="h-5 w-5 text-primary group-hover:text-secondary transition-colors duration-500" />
                                        </div>
                                        <span className="text-lg text-text-primary group-hover:text-primary transition-all duration-500 font-medium group-hover:translate-x-1">
                                            {item}
                                        </span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                    {/* Right Column: Image */}
                    <div ref={imageRef} className="lg:w-1/2 w-full relative group">
                        {/* Glowing border effect */}
                        <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
                            style={{
                                background: 'linear-gradient(135deg, rgba(199,162,77,0.5), rgba(217,125,37,0.5), rgba(176,66,198,0.3))',
                                filter: 'blur(25px)',
                                transform: 'scale(1.05)',
                            }}
                        />
                        
                        <div className="relative overflow-hidden rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-700 ring-2 ring-primary/10 group-hover:ring-4 group-hover:ring-primary/30">
                            <Image
                                src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-1560-x-1440-px-1560-x-740-px-2-scaled-10.png"
                                alt="Heat map visualization of geographical data"
                                width={1560}
                                height={740}
                                className="w-full h-auto transition-transform duration-700 group-hover:scale-105"
                            />
                            {/* Gradient overlay on hover */}
                            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ProfessionalApproach;
