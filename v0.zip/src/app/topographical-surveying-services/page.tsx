import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Advanced Topographical Surveying",
    content: [
      "We provide comprehensive topographical surveying services using the latest technologies including LIDAR 3D mapping, Building Information Modeling (BIM), Revit modeling, 3D laser scanning, and 3D imaging. Our surveys capture detailed terrain information essential for engineering, construction, and planning projects.",
      "Our topographical surveys deliver accurate elevation data, contour lines, natural and man-made features, and precise measurements that serve as the foundation for successful project design and execution."
    ]
  },
  {
    title: "Cutting-Edge Technology",
    content: [
      "Using advanced surveying equipment including terrestrial laser scanners, UAV-based LIDAR systems, and total stations, we capture high-resolution topographic data with exceptional accuracy. This data is processed into detailed 3D models, digital elevation models (DEMs), and CAD-ready drawings.",
      "Our BIM and Revit modeling services bridge the gap between surveying and design, providing architects and engineers with accurate as-built models and detailed site information for seamless project integration."
    ]
  }
];

const features = [
  "LIDAR 3D mapping and point cloud processing",
  "3D laser scanning and modeling",
  "Building Information Modeling (BIM)",
  "Revit modeling and integration",
  "Digital elevation models (DEM) and contour mapping",
  "Volumetric analysis and calculations",
  "As-built surveys and documentation",
  "UAV/drone-based topographic surveys"
];

export default function TopographicalSurveyingServicesPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Topographical Surveying Services"
          description="State-of-the-art topographical surveying including LIDAR 3D mapping, BIM, Revit modeling, 3D laser scanning, and advanced imaging technologies."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-20-1-6.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
