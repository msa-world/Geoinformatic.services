"use client"

import { useEffect, useState, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "sonner"
import { FileIcon, FolderIcon, Link, Trash2, Download, RefreshCw, LogOut, Upload, Loader2, ArrowUp, ArrowDown, HardDrive, Eye, MoreHorizontal } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'

// Helper function to format file size in a human-readable way
function formatBytes(bytes: number | string, decimals = 2) {
  const num = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes;
  if (num === 0 || isNaN(num)) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(num) / Math.log(k));
  return parseFloat((num / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Simple component to determine file icon based on mime type or extension
const FileTypeIcon = ({ name, mimeType }: { name: string, mimeType: string }) => {
  if (mimeType === 'application/vnd.google-apps.folder') {
    return <FolderIcon className="w-5 h-5 text-yellow-500" />;
  }
  if (name.toLowerCase().endsWith('.rar')) {
    return <FileIcon className="w-5 h-5 text-blue-500" />;
  }
  return <FileIcon className="w-5 h-5 text-gray-500" />;
}

// Type for files (assuming size and owner are present)
type DriveFile = {
  id: string;
  name: string;
  mimeType: string;
  size?: string; // size is a string of bytes from Google Drive API
  modifiedTime: string;
  webViewLink?: string;
  owner?: string;
}

export default function ProfileDrivePage() {
  const supabase = createClient()
  const [userId, setUserId] = useState<string | null>(null)
  const [connectedAt, setConnectedAt] = useState<string | null>(null)
  const [scope, setScope] = useState<string | null>(null)
  const [files, setFiles] = useState<DriveFile[]>([])
  const [folders, setFolders] = useState<DriveFile[]>([])
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null)
  const [breadcrumbs, setBreadcrumbs] = useState<Array<{ id: string | null; name: string }>>([
    { id: null, name: 'My Drive' },
  ])
  const [loading, setLoading] = useState(false)
  // NEW STATE: To store Drive storage usage information
  const [storageInfo, setStorageInfo] = useState<{ used: string | null, total: string | null }>({ used: null, total: null })
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'ascending' | 'descending' }>({
    key: 'name',
    direction: 'ascending',
  });

  const [searchQuery, setSearchQuery] = useState<string>('')
  const [searching, setSearching] = useState<boolean>(false)
  const [listAnimating, setListAnimating] = useState<boolean>(false)

  // ref for storage progress bar to set width at runtime (avoids inline width in JSX)
  const storageProgressRef = useRef<HTMLDivElement | null>(null)

  // Transfer tracking state for uploads/downloads
  const [transfers, setTransfers] = useState<Record<string, { id: string; type: 'upload' | 'download' | 'delete'; name: string; progress: number; status: 'running' | 'done' | 'error' }>>({})

  function addTransfer(type: 'upload' | 'download' | 'delete', name: string) {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    setTransfers((prev) => ({ ...prev, [id]: { id, type, name, progress: 0, status: 'running' } }))
    return id
  }

  function updateTransfer(id: string, patch: Partial<{ progress: number; status: 'running' | 'done' | 'error' }>) {
    setTransfers((prev) => {
      const existing = prev[id]
      if (!existing) return prev
      const updated = { ...existing, ...patch }
      const next = { ...prev, [id]: updated }
      return next
    })
    if (patch.status === 'done' || patch.status === 'error') {
      // auto-remove after a short delay
      setTimeout(() => {
        setTransfers((prev) => {
          const copy = { ...prev }
          delete copy[id]
          return copy
        })
      }, 3000)
    }
  }
  // Function to fetch files and optionally storage information.
  // options.suppressLoading: if true, do not set the global `loading` state (used for fast, optimistic UI updates)
  // options.updateStorage: if true, fetch storage info from the server (only needed for initial load or explicit refresh)
  async function fetchDriveData(
    id: string,
    parentId: string | null = null,
    search: string | null = null,
    options?: { suppressLoading?: boolean; updateStorage?: boolean },
  ) {
    const suppressLoading = options?.suppressLoading ?? false
    const updateStorage = options?.updateStorage ?? false
    try {
      if (suppressLoading) setListAnimating(true)
      if (!suppressLoading) setLoading(true)

      // 1. Fetch Files (server-side search and parent filtering)
      const url = new URL(`/api/google/list`, location.origin)
      url.searchParams.set('userId', id)
      if (parentId) url.searchParams.set('parentId', parentId)
      if (search && search.trim().length > 0) url.searchParams.set('search', search.trim())
      const fileRes = await fetch(url.toString())
      const fileBody = await fileRes.json()

      if (!fileBody.success) {
        toast(fileBody.message || "Failed to list Drive files")
        setFiles([])
      } else {
        const rawFiles = fileBody.files?.files ?? fileBody.files ?? []
        // Normalize Drive API response into our local shape
        const normalizedFiles: DriveFile[] = rawFiles.map((f: any) => ({
          id: f.id,
          name: f.name,
          mimeType: f.mimeType,
          size: f.size,
          modifiedTime: f.modifiedTime || null,
          webViewLink: f.webViewLink || null,
          owner: (f.owners && f.owners[0] && f.owners[0].displayName) ? f.owners[0].displayName : 'You',
        }))
        setFiles(normalizedFiles)
        // extract folders for the folder picker/navigation
        const folderList = normalizedFiles.filter((x) => x.mimeType === 'application/vnd.google-apps.folder')
        setFolders(folderList)
      }

      // 2. Optionally fetch Storage Info. Do this only on initial load or explicit refresh to avoid slow round-trips.
      if (updateStorage) {
        const storageRes = await fetch(`/api/google/storage?userId=${encodeURIComponent(id)}`)
        const storageBody = await storageRes.json()
        if (storageBody.success && storageBody.storageQuota) {
          setStorageInfo({
            used: storageBody.storageQuota.usage,
            total: storageBody.storageQuota.limit,
          })
        }
      }
    } catch (err) {
      console.error("[v0] drive data fetch error", err)
      toast("Failed to fetch Drive data")
    } finally {
      if (!suppressLoading) setLoading(false)
      if (suppressLoading) setListAnimating(false)
    }
  }

  // Debounce searchQuery and call fetchDriveData when it changes
  useEffect(() => {
    if (!userId) return
    setSearching(true)
    const t = setTimeout(async () => {
      try {
        // For searches we want snappy UI updates; suppress the heavy loading indicator and skip storage refresh
        await fetchDriveData(userId, currentFolderId, searchQuery || null, { suppressLoading: true, updateStorage: false })
      } finally {
        setSearching(false)
      }
    }, 400)
    return () => clearTimeout(t)
  }, [searchQuery, currentFolderId, userId])

  useEffect(() => {
    const init = async () => {
      try {
        const { data } = await supabase.auth.getUser()
        const u = data?.user
        if (!u) return
        setUserId(u.id)

        const { data: profile } = await supabase.from("profiles").select("google_connected_at,google_scope").eq("id", u.id).single()
        if (profile) {
          setConnectedAt(profile.google_connected_at ?? null)
          setScope(profile.google_scope ?? null)
          if (profile.google_connected_at) {
            // Initial load: fetch files AND storage info and show the loading banner
            await fetchDriveData(u.id, null, searchQuery || null, { suppressLoading: false, updateStorage: true })
          }
        }
      } catch (err) {
        console.error("[v0] drive init error", err)
      }
    }

    init()
  }, [])

  async function startConnect() {
    // ... (logic unchanged)
    // The redirect handles the connection process.
    if (!userId) return toast("Please login first")
    try {
      const res = await fetch("/api/google/oauth/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      })
      const body = await res.json()
      if (!body.success) throw new Error(body.message || "Failed to start OAuth")
      window.location.href = body.url
    } catch (err) {
      console.error(err)
      toast("Failed to start Google Connect")
    }
  }

  async function refresh() {
    if (!userId) return
    // Refresh calls the new combined data function
    await fetchDriveData(userId, currentFolderId, searchQuery || null, { suppressLoading: false, updateStorage: true })
    toast("Refreshed")
  }

  async function disconnect() {
    // ... (logic unchanged)
    if (!userId) return
    try {
      const res = await fetch('/api/google/disconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      })
      const body = await res.json()
      if (!body.success) {
        console.error('disconnect failed', body)
        toast('Disconnect failed')
        return
      }
      setConnectedAt(null)
      setScope(null)
      setFiles([])
      setStorageInfo({ used: null, total: null }) // Clear storage info
      toast('Disconnected from Google Drive')
    } catch (err) {
      console.error('[v0] disconnect error', err)
      toast('Failed to disconnect')
    }
  }

  // UPLOAD LOGIC: The "real logic" for the client-side is handling the file input, 
  // reading it as Base64, and POSTing it to the server API, which is done correctly below.
  async function handleUploadFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !userId) return
    // delegate to programmatic uploader which tracks progress
    try {
      await uploadFileTo(file, currentFolderId)
    } catch (err) {
      console.error('upload err', err)
    }
  }

  // DOWNLOAD LOGIC: The "real logic" for the client-side is fetching the file data as a Blob, 
  // creating a temporary URL for the Blob, and triggering a download, which is correct below.
  async function downloadFile(fileId: string, name?: string) {
    if (!userId) return
    const transferId = addTransfer('download', name || 'file')
    try {
      const res = await fetch(`/api/google/download?userId=${encodeURIComponent(userId)}&fileId=${encodeURIComponent(fileId)}`)
      if (!res.ok) {
        let payload: any = null
        try { payload = await res.json() } catch (e) { /* ignore */ }
        console.error('download failed', payload)
        updateTransfer(transferId, { status: 'error' })
        toast('Download failed')
        return
      }

      const contentLength = res.headers.get('content-length')
      if (res.body && contentLength) {
        const total = parseInt(contentLength, 10)
        const reader = res.body.getReader()
        const chunks: Uint8Array[] = []
        let received = 0
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            if (value) {
              chunks.push(value)
              received += value.byteLength
              const p = Math.round((received / total) * 100)
              updateTransfer(transferId, { progress: p })
            }
          }
          // concatenate chunks into a single Uint8Array
          const combined = new Uint8Array(received)
          let offset = 0
          for (const chunk of chunks) {
            combined.set(chunk, offset)
            offset += chunk.byteLength
          }
          const blob = new Blob([combined.buffer], { type: res.headers.get('content-type') || 'application/octet-stream' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = name || 'file'
        document.body.appendChild(a)
        a.click()
        a.remove()
        setTimeout(() => URL.revokeObjectURL(url), 60000)
        updateTransfer(transferId, { progress: 100, status: 'done' })
        toast.success('Download complete')
        return
      }

      // Fallback when no content-length or body not streamable
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = name || 'file'
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 60000)
      updateTransfer(transferId, { progress: 100, status: 'done' })
      toast.success('Download complete')
    } catch (err) {
      console.error('download err', err)
      updateTransfer(transferId, { status: 'error' })
      toast.error('Download failed')
    }
  }

  // Upload a single File object into an optional parent folder (parentId)
  async function uploadFileTo(file: File, parentId?: string | null) {
    if (!file || !userId) return

    return new Promise<void>((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => {
        try {
          const result = reader.result as string
          const base64 = result.split(',')[1]
          const payloadObj: any = { userId, name: file.name, mimeType: file.type, data: base64 }
          if (parentId) payloadObj.parentId = parentId
          const payload = JSON.stringify(payloadObj)

          const transferId = addTransfer('upload', file.name)
          const xhr = new XMLHttpRequest()
          xhr.open('POST', '/api/google/upload')
          xhr.setRequestHeader('Content-Type', 'application/json')
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              const p = Math.round((e.loaded / e.total) * 100)
              updateTransfer(transferId, { progress: p })
            }
          }
          xhr.onload = async () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              try {
                const body = JSON.parse(xhr.responseText)
                  if (body.success) {
                  updateTransfer(transferId, { progress: 100, status: 'done' })
                  toast.success('Upload succeeded')
                  // If server returned the uploaded file, optimistically insert it so it appears immediately
                  if (body.file) {
                    const nf: DriveFile = {
                      id: body.file.id,
                      name: body.file.name || file.name,
                      mimeType: body.file.mimeType || file.type || 'application/octet-stream',
                      modifiedTime: body.file.modifiedTime || new Date().toISOString(),
                      webViewLink: body.file.webViewLink || null,
                      owner: 'You',
                    }
                    setFiles((prev) => [nf, ...prev])
                    if (nf.mimeType === 'application/vnd.google-apps.folder') setFolders((prev) => [nf, ...prev])
                  }
                  if (userId) await fetchDriveData(userId, currentFolderId, searchQuery || null, { suppressLoading: true, updateStorage: false })
                  resolve()
                } else {
                  updateTransfer(transferId, { status: 'error' })
                  toast.error('Upload failed')
                  reject(body)
                }
              } catch (err) {
                updateTransfer(transferId, { status: 'error' })
                toast.error('Upload failed')
                reject(err)
              }
            } else {
              updateTransfer(transferId, { status: 'error' })
              toast.error('Upload failed')
              reject(new Error('Upload failed'))
            }
          }
          xhr.onerror = () => {
            updateTransfer(transferId, { status: 'error' })
            toast.error('Upload failed')
            reject(new Error('Network error'))
          }
          xhr.send(payload)
        } catch (err) {
          console.error('reader.onload err', err)
          toast.error('Upload failed')
          reject(err)
        }
      }
      reader.onerror = (e) => {
        console.error('file read error', e)
        toast.error('Upload failed')
        reject(e)
      }
      reader.readAsDataURL(file)
    })
  }

  // Programmatically open a file picker and upload into parentId
  function openFilePickerTo(parentId?: string | null) {
    const input = document.createElement('input')
    input.type = 'file'
    input.onchange = (e: Event) => {
      const target = e.target as HTMLInputElement
      const file = target.files?.[0]
      if (file) uploadFileTo(file, parentId)
    }
    input.click()
  }

  // PREVIEW: Open files inline when possible. For Google-native files (Docs/Sheets/Slides)
  // prefer the Drive webViewLink so the user sees the native preview. For binary files,
  // fetch the server download endpoint and open PDFs/images/text/audio/video in a new tab.
  async function previewFile(file: DriveFile) {
    if (!userId) return
    try {
      // If we have a webViewLink, open it in a new tab. This works well for Google-native files
      // and for many files where Drive provides an in-browser viewer.
      if (file.webViewLink) {
        window.open(file.webViewLink, '_blank', 'noopener')
        return
      }

      // Otherwise, fetch the downloaded content from our server which already handles
      // Google-native exports (export -> pdf/xlsx/pptx) and regular media files.
      const res = await fetch(`/api/google/download?userId=${encodeURIComponent(userId)}&fileId=${encodeURIComponent(file.id)}`)
      if (!res.ok) {
        // try to parse json error body
        let payload: any = null
        try { payload = await res.json() } catch (e) { /* ignore */ }
        console.error('preview fetch failed', payload)
        toast(payload?.message || 'Failed to preview file')
        return
      }

      const contentType = res.headers.get('content-type') || ''
      const blob = await res.blob()

      // Displayable types: images, pdfs, text, audio, video
      if (contentType.startsWith('image/') || contentType === 'application/pdf' || contentType.startsWith('text/') || contentType.startsWith('audio/') || contentType.startsWith('video/')) {
        const url = URL.createObjectURL(blob)
        window.open(url, '_blank', 'noopener')
        // revoke later
        setTimeout(() => URL.revokeObjectURL(url), 60000)
        return
      }

      // For unknown types, fall back to download with suggested filename
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = file.name || 'file'
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 60000)
    } catch (err) {
      console.error('preview err', err)
      toast('Failed to preview file')
    }
  }

  // Navigation helpers: double-click to open files or enter folders
  const handleDoubleClick = async (file: DriveFile) => {
    if (file.mimeType === 'application/vnd.google-apps.folder') {
      // navigate into folder
      await navigateIntoFolder(file)
    } else {
      // preview file
      await previewFile(file)
    }
  }

  const navigateIntoFolder = async (folder: DriveFile) => {
    // push to breadcrumb and fetch children
    setBreadcrumbs((prev) => [...prev, { id: folder.id, name: folder.name }])
    setCurrentFolderId(folder.id)
    if (!userId) return
    // Immediately clear the visible list and show skeleton/animation so navigation feels instant
    setFiles([])
    setFolders([])
    // Load the folder contents without the heavy loading banner for snappy navigation
    await fetchDriveData(userId, folder.id, searchQuery || null, { suppressLoading: true, updateStorage: false })
  }

  // Delete logic (unchanged)
  async function deleteFile(fileId: string) {
    if (!userId) return
    if (!confirm('Delete this file from your Google Drive?')) return
    const fileName = files.find((x) => x.id === fileId)?.name || 'Deleting file'
    const transferId = addTransfer('delete', fileName)
    try {
      const res = await fetch('/api/google/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, fileId }),
      })
      const body = await res.json()
      if (!body.success) {
        console.error('delete failed', body)
        updateTransfer(transferId, { status: 'error' })
        toast.error('Delete failed')
      } else {
        updateTransfer(transferId, { progress: 100, status: 'done' })
        toast.success('Deleted')
        // Optimistically remove the deleted item from local state so UI updates immediately without a loading banner
        setFiles((prev) => prev.filter((f) => f.id !== fileId))
        setFolders((prev) => prev.filter((f) => f.id !== fileId))
        // Optionally, quietly refresh the listing in background to ensure consistency (no loading banner)
        if (userId) fetchDriveData(userId, currentFolderId, searchQuery || null, { suppressLoading: true, updateStorage: false }).catch(() => {})
      }
    } catch (err) {
      console.error('delete err', err)
      updateTransfer(transferId, { status: 'error' })
      toast.error('Delete failed')
    }
  }


  // --- UI/UX Enhancements & Sorting Logic (from previous step, with minor updates) ---

  const requestSort = (key: string) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const sortedFiles = [...files].sort((a: any, b: any) => {
    const isAscending = sortConfig.direction === 'ascending';
    const key = sortConfig.key;

    if (key === 'name') {
      return a.name.localeCompare(b.name) * (isAscending ? 1 : -1);
    }
    if (key === 'modifiedTime') {
      const dateA = new Date(a.modifiedTime).getTime();
      const dateB = new Date(b.modifiedTime).getTime();
      return (dateA - dateB) * (isAscending ? 1 : -1);
    }
    if (key === 'size') {
      const sizeA = a.size ? parseInt(a.size) : isAscending ? -Infinity : Infinity;
      const sizeB = b.size ? parseInt(b.size) : isAscending ? -Infinity : Infinity;
      return (sizeA - sizeB) * (isAscending ? 1 : -1);
    }
    return 0;
  });

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'ascending' ? <ArrowUp className="w-3 h-3 ml-1" /> : <ArrowDown className="w-3 h-3 ml-1" />;
  };

  const getTableHeaderClass = (key: string) => {
    const base = "cursor-pointer select-none py-2 px-4 flex items-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors";
    const isActive = sortConfig.key === key;
    return `${base} ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400'}`;
  }

  // --- RENDERING ---
  const usedStorage = storageInfo.used ? parseInt(storageInfo.used) : 0;
  const totalStorage = storageInfo.total ? parseInt(storageInfo.total) : 1; // Prevent division by zero
  const storagePercentage = totalStorage > 0 ? ((usedStorage / totalStorage) * 100).toFixed(2) : '0';

  // Apply storage progress width at runtime via ref to avoid inline JSX width style
  useEffect(() => {
    if (storageProgressRef.current) {
      storageProgressRef.current.style.width = `${storagePercentage}%`
    }
  }, [storagePercentage])
  return (
    <div className="min-h-screen w-full bg-gray-50 dark:bg-gray-900">
      {/* Transfer status panel (uploads/downloads) */}
      <div className="fixed right-6 top-6 z-50 flex flex-col gap-2">
        {Object.values(transfers).map((t) => (
          <div key={t.id} className="w-64 bg-white dark:bg-gray-800 border rounded-md p-2 shadow flex items-center gap-2">
            <div className="flex-1">
              <div className="text-sm font-medium truncate">{t.name}</div>
              <div className="w-full h-2 bg-gray-200 rounded mt-2">
                <div className="h-2 bg-blue-600 rounded transition-all" style={{ width: `${t.progress}%` }} />
              </div>
            </div>
            <div className="w-12 text-right text-sm">{t.progress}%</div>
          </div>
        ))}
      </div>
      <div className="container mx-auto px-4 py-8">
        <Card className="shadow-xl border-t-4 border-blue-600 dark:border-blue-400">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <Link className="w-6 h-6 text-blue-600" />
                Google Drive Integration
            </CardTitle>
            <div className="flex gap-3">
              <Button onClick={startConnect} disabled={!!connectedAt} variant="default" className="bg-blue-600 hover:bg-blue-700 text-white">
                Connect Drive
              </Button>
              <Button onClick={refresh} variant="outline" disabled={!connectedAt || loading} className="flex items-center gap-1">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Refresh
              </Button>
              <Button onClick={disconnect} variant="destructive" disabled={!connectedAt} className="flex items-center gap-1">
                <LogOut className="w-4 h-4" />
                Disconnect
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-gray-600 dark:text-gray-300">
              Connection Status: 
              <span className={`font-semibold ml-2 ${connectedAt ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                {connectedAt ? `Connected since ${new Date(connectedAt).toLocaleString()}` : "Not connected"}
              </span>
              {scope && <span className="ml-4 text-xs"> (Scope: {scope})</span>}
            </p>
            
            <hr className="my-4" />

            {/* Storage Usage Section (NEW LOGIC DISPLAY) */}
            <div className="flex items-center justify-between gap-4 py-2">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 font-semibold">
                    <HardDrive className="w-5 h-5 text-blue-600" />
                    Drive Storage Used
                </div>
                <div className="text-sm font-semibold whitespace-nowrap">
                    {storageInfo.used && storageInfo.total ? (
                        <span className="text-gray-800 dark:text-gray-200">
                            {formatBytes(usedStorage)} of {formatBytes(totalStorage)}
                        </span>
                    ) : (
                        <span className="text-gray-500">—</span>
                    )}
                </div>
            </div>
            {storageInfo.used && storageInfo.total && (
                <>
                <div className="w-full h-2 bg-gray-200 rounded-full dark:bg-gray-700">
          <div 
            ref={storageProgressRef}
            className="h-2 bg-blue-600 rounded-full transition-all duration-500 storage-progress" 
            data-progress={storagePercentage}
            title={`${storagePercentage}% used`}
          ></div>
                </div>
                <p className="text-xs text-right text-gray-500 dark:text-gray-400 mt-1">{storagePercentage}% used</p>
                </>
            )}

            <hr className="my-4" />

            {/* Simulated Drive Toolbar: Upload and Filter controls */}
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">
                    Shared with me / RAWAPINDI
                </h3>
                
                <div className="flex items-center gap-3">
          {/* Folder picker + create */}
          <div className="flex items-center gap-3">
            <nav className="text-sm flex items-center gap-2">
              {breadcrumbs.map((bc, idx) => (
                <span key={(bc.id ?? 'root') + idx} className="flex items-center gap-2">
                  {idx > 0 && <span className="text-gray-400">/</span>}
                  <button
                    className={`text-sm ${idx === breadcrumbs.length - 1 ? 'font-semibold text-gray-900 dark:text-gray-100' : 'text-blue-600'}`}
                    onClick={async () => {
                      // navigate to breadcrumb index
                                        const newCrumbs = breadcrumbs.slice(0, idx + 1)
                                        setBreadcrumbs(newCrumbs)
                                        const targetId = bc.id ?? null
                                        setCurrentFolderId(targetId)
                                        if (userId) await fetchDriveData(userId, targetId, searchQuery || null, { suppressLoading: true, updateStorage: false })
                    }}
                  >
                    {bc.name}
                  </button>
                </span>
              ))}
            </nav>
            <Button size="sm" variant="outline" onClick={async () => {
              const name = prompt('New folder name')
              if (!name || !userId) return
              try {
                const res = await fetch('/api/google/create-folder', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ userId, folderName: name, parentId: currentFolderId || undefined }),
                })
                const body = await res.json()
                if (!body.success) {
                  console.error('create folder failed', body)
                  toast('Failed to create folder')
                  return
                }
                toast('Folder created')
                // Optimistically add the new folder to the UI so it appears immediately
                if (body.folder) {
                  const nf: DriveFile = {
                    id: body.folder.id,
                    name: body.folder.name || name,
                    mimeType: body.folder.mimeType || 'application/vnd.google-apps.folder',
                    modifiedTime: body.folder.modifiedTime || new Date().toISOString(),
                    webViewLink: body.folder.webViewLink || null,
                    owner: 'You',
                  }
                  setFiles((prev) => [nf, ...prev])
                  setFolders((prev) => [nf, ...prev])
                }
                // refresh list to show folder (suppress heavy loading banner for snappy UX)
                if (userId) await fetchDriveData(userId, currentFolderId, searchQuery || null, { suppressLoading: true, updateStorage: false })
              } catch (err) {
                console.error('create folder err', err)
                toast('Failed to create folder')
              }
            }}>New folder</Button>
          </div>
                    {/* Simplified Filter Buttons */}
                    <Button variant="outline" size="sm" className="text-xs">Type</Button>
                    <Button variant="outline" size="sm" className="text-xs">People</Button>
                    <Button variant="outline" size="sm" className="text-xs">Modified</Button>
                    
                    {/* Search input replaces the top Upload button (client-side debounced search) */}
                    <div className="relative">
                      <input
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={searching ? 'Searching...' : 'Search Drive...'}
                        className="px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-400"
                        aria-label="Search Drive"
                        title="Search Drive"
                      />
                    </div>
                </div>
            </div>

            {/* File List Table Structure */}
            <div className="border rounded-lg overflow-hidden">
        <div className={`${listAnimating ? 'opacity-80' : 'opacity-100'} transition-opacity duration-200`}>
                {/* Table Header Row */}
                <div className="grid grid-cols-12 bg-gray-100 dark:bg-gray-800 border-b font-semibold text-sm">
                    <div className="col-span-5">
                        <div className={getTableHeaderClass('name')} onClick={() => requestSort('name')}>
                            Name
                            {getSortIcon('name')}
                        </div>
                    </div>
                    <div className="col-span-2">
                        <div className={getTableHeaderClass('owner')} onClick={() => requestSort('owner')}>
                            Owner
                            {getSortIcon('owner')}
                        </div>
                    </div>
                    <div className="col-span-2">
                        <div className={getTableHeaderClass('modifiedTime')} onClick={() => requestSort('modifiedTime')}>
                            Date modified
                            {getSortIcon('modifiedTime')}
                        </div>
                    </div>
                    <div className="col-span-1">
                        <div className={getTableHeaderClass('size')} onClick={() => requestSort('size')}>
                            File size
                            {getSortIcon('size')}
                        </div>
                    </div>
                    <div className="col-span-2">
                        <div className="py-2 px-4 text-center">Actions</div>
                    </div>
                </div>

        {loading && (
                    <div className="p-8 text-center text-gray-500 dark:text-gray-400">
                        <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
                        Loading files and storage info…
                    </div>
                )}
                {!loading && sortedFiles.length === 0 && (
                  currentFolderId ? (
                    <div className="p-8 text-center">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">This folder is empty.</p>
                      <div className="flex items-center justify-center">
                        <Button onClick={() => openFilePickerTo(currentFolderId)} disabled={!connectedAt || loading} className="bg-green-600 hover:bg-green-700 text-white">
                          <Upload className="w-4 h-4 mr-2" />
                          Upload data
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-center p-8 text-muted-foreground">No files to show.</p>
                  )
                )}
                {/* Show lightweight skeleton rows when listAnimating is true to mask latency */}
                {!loading && listAnimating && (
                  <div className="p-2 space-y-2">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="flex items-center gap-3 py-2 px-4 bg-white dark:bg-gray-900 rounded shadow-sm animate-pulse">
                        <div className="w-6 h-6 bg-gray-200 dark:bg-gray-700 rounded" />
                        <div className="flex-1">
                          <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-2" />
                          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded w-1/4" />
                        </div>
                        <div className="w-24 h-3 bg-gray-200 dark:bg-gray-700 rounded" />
                      </div>
                    ))}
                  </div>
                )}
                
        {/* File List Body */}
                {!loading && sortedFiles.map((f: DriveFile, index) => (
          <div 
            key={f.id} 
            onDoubleClick={() => handleDoubleClick(f)}
            role={f.mimeType === 'application/vnd.google-apps.folder' ? 'button' : undefined}
            className={`grid grid-cols-12 items-center hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors ${index % 2 === 0 ? 'bg-white dark:bg-gray-900' : 'bg-gray-50 dark:bg-gray-850'}`}
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                handleDoubleClick(f)
              }
            }}
          >
                        {/* Name Column */}
                        <div className="col-span-5 flex items-center gap-3 py-2 px-4 truncate">
                            <FileTypeIcon name={f.name} mimeType={f.mimeType} />
                            <p className="font-medium text-sm truncate">{f.name}</p>
                        </div>
                        {/* Owner Column (Simulated) */}
                        <div className="col-span-2 py-2 px-4 text-sm text-gray-600 dark:text-gray-400 truncate">
                            {f.owner || "—"}
                        </div>
                        {/* Date Modified Column */}
                        <div className="col-span-2 py-2 px-4 text-sm text-gray-600 dark:text-gray-400 truncate">
                            {f.modifiedTime ? new Date(f.modifiedTime).toLocaleDateString() : "—"}
                        </div>
                        {/* File Size Column */}
                        <div className="col-span-1 py-2 px-4 text-sm text-gray-600 dark:text-gray-400 truncate">
                            {f.size ? formatBytes(f.size) : "—"}
                        </div>
                        {/* Actions Column: only a single 3-dots menu per row (no standalone icons) */}
                        <div className="col-span-2 py-2 px-4 flex justify-center items-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost" aria-label={`More actions for ${f.name}`} title="More actions">
                                <MoreHorizontal className="w-4 h-4 text-gray-600" />
                              </Button>
                            </DropdownMenuTrigger>

                            <DropdownMenuContent align="start">
                              {/* Upload here: if row is a folder upload into that folder, else upload into currentFolderId */}
                              <DropdownMenuItem onClick={() => openFilePickerTo(f.mimeType === 'application/vnd.google-apps.folder' ? f.id : currentFolderId)}>
                                <Upload className="w-4 h-4" />
                                <span>Upload here</span>
                              </DropdownMenuItem>

                              <DropdownMenuSeparator />

                              <DropdownMenuItem onClick={() => previewFile(f)}>
                                <Eye className="w-4 h-4" />
                                <span>Preview</span>
                              </DropdownMenuItem>

                              <DropdownMenuItem onClick={() => downloadFile(f.id, f.name)}>
                                <Download className="w-4 h-4" />
                                <span>Download</span>
                              </DropdownMenuItem>

                              <DropdownMenuItem asChild>
                                <a href={f.webViewLink || `https://drive.google.com/file/d/${f.id}/view`} target="_blank" rel="noreferrer">
                                  <Link className="w-4 h-4" />
                                  <span>Open in Drive</span>
                                </a>
                              </DropdownMenuItem>

                              <DropdownMenuSeparator />

                              <DropdownMenuItem onClick={() => deleteFile(f.id)} className="text-red-600" data-variant="destructive">
                                <Trash2 className="w-4 h-4" />
                                <span>Delete</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                    </div>
                ))}
            </div>
          </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}