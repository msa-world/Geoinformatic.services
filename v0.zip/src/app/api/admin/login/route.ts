import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] Admin login API called")

    // Check content type
    const contentType = request.headers.get("content-type")
    if (!contentType?.includes("application/json")) {
      console.log("[v0] Invalid content type:", contentType)
      return NextResponse.json(
        { success: false, message: "Content-Type must be application/json" },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      )
    }

    // Parse request body
    let body
    try {
      body = await request.json()
      console.log("[v0] Request body parsed successfully")
    } catch (error) {
      console.error("[v0] JSON parse error:", error)
      return NextResponse.json(
        { success: false, message: "Invalid JSON in request body" },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      )
    }

    const { username, password } = body

    if (!username || !password) {
      console.log("[v0] Missing username or password")
      return NextResponse.json(
        { success: false, message: "Username and password are required" },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      )
    }

    const ADMIN_USERNAME = "admin"
    const ADMIN_PASSWORD = "Geo@1122"

    console.log("[v0] Checking credentials for username:", username)

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // Create a simple token
      const token = Buffer.from(`${username}:${Date.now()}`).toString("base64")

      console.log("[v0] Admin login successful")

      return NextResponse.json(
        {
          success: true,
          message: "Login successful",
          token: token,
          username: username,
        },
        {
          status: 200,
          headers: { "Content-Type": "application/json" },
        },
      )
    } else {
      console.log("[v0] Invalid credentials provided")
      return NextResponse.json(
        { success: false, message: "Invalid username or password" },
        {
          status: 401,
          headers: { "Content-Type": "application/json" },
        },
      )
    }
  } catch (error) {
    console.error("[v0] Unexpected error in admin login:", error)
    const errorMessage = error instanceof Error ? error.message : "Internal server error"
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    )
  }
}
