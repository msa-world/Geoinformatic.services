"use client"

import HeaderNavigation from "@/components/sections/header-navigation"
import Footer from "@/components/sections/footer"
import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Globe, Database, BarChart3, Zap } from "lucide-react"

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

const features = [
  {
    icon: Globe,
    title: "Global Coverage",
    description: "Access geospatial data from anywhere in the world with our comprehensive Web GIS platform.",
  },
  {
    icon: Database,
    title: "Advanced Data Management",
    description:
      "Manage, store, and organize large-scale spatial datasets efficiently with cloud-based infrastructure.",
  },
  {
    icon: BarChart3,
    title: "Real-time Analytics",
    description: "Perform spatial analysis and generate insights in real-time with powerful analytical tools.",
  },
  {
    icon: Zap,
    title: "High Performance",
    description: "Lightning-fast data processing and visualization for seamless user experience.",
  },
]

const capabilities = [
  "Interactive web mapping",
  "Spatial data visualization",
  "Advanced query functionality",
  "Custom reporting tools",
  "Multi-layer analysis",
  "Real-time data streaming",
]

export default function WebGISServicesPage() {
  const titleRef = useRef<HTMLDivElement>(null)
  const featuresRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!titleRef.current) return

    const title = titleRef.current.querySelector("h1")
    if (title) {
      const text = title.textContent || ""
      title.innerHTML = `<span class="text-fill-wrapper">${text}</span>`
      const fillSpan = title.querySelector(".text-fill-wrapper") as HTMLElement

      if (fillSpan) {
        fillSpan.style.cssText = `
          display: inline-block;
          position: relative;
          background: linear-gradient(to right, #07223F 0%, #07223F 50%, transparent 50%);
          background-size: 200% 100%;
          background-position: 100% 0;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        `

        gsap.to(fillSpan, {
          backgroundPosition: "0% 0",
          ease: "none",
          scrollTrigger: {
            trigger: title,
            start: "top 70%",
            end: "top 30%",
            scrub: 1,
          },
        })
      }
    }

    if (featuresRef.current) {
      const cards = featuresRef.current.querySelectorAll(".feature-card")
      cards.forEach((card, index) => {
        gsap.from(card, {
          y: 60,
          opacity: 0,
          duration: 0.8,
          delay: index * 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: card,
            start: "top 85%",
            toggleActions: "play none none none",
          },
        })
      })
    }

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [])

  return (
    <>
      <HeaderNavigation />
      <main className="w-full">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-[#07223F] via-[#1A1A1A] to-[#2D4A5F] pt-32 pb-20 overflow-hidden">
          {/* Background decoration */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div
              className="absolute top-20 right-10 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse"
              style={{ animationDuration: "6s" }}
            />
            <div
              className="absolute bottom-10 left-10 w-80 h-80 bg-secondary/10 rounded-full blur-3xl animate-pulse"
              style={{ animationDuration: "7s", animationDelay: "1s" }}
            />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div ref={titleRef} className="max-w-3xl mx-auto text-center mb-12">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6">Web GIS Services</h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Transform your geospatial data into actionable intelligence with our cutting-edge Web GIS platform.
                Access, analyze, and visualize geographic information anytime, anywhere.
              </p>
            </div>

            <div className="relative h-96 rounded-2xl overflow-hidden shadow-2xl ring-2 ring-primary/30 group">
              <Image
                src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-10-3.png"
                alt="Web GIS interface visualization"
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 bg-gradient-to-b from-white via-gray-50/30 to-white">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl md:text-5xl font-bold text-center text-text-primary mb-16">Powerful Features</h2>

            <div ref={featuresRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <div
                    key={index}
                    className="feature-card group bg-white/80 backdrop-blur-sm rounded-xl p-8 hover:bg-white transition-all duration-500 shadow-lg hover:shadow-2xl hover:shadow-primary/20"
                  >
                    <div className="w-14 h-14 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 group-hover:from-primary/40 group-hover:to-secondary/40 transition-all duration-500">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-text-primary mb-3 group-hover:text-primary transition-colors duration-500">
                      {feature.title}
                    </h3>
                    <p className="text-text-secondary leading-relaxed group-hover:text-text-primary/80 transition-colors duration-500">
                      {feature.description}
                    </p>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Capabilities Section */}
        <section className="py-24 bg-gradient-to-br from-[#D9A561] via-[#C7A24D] to-[#7FA89A]">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Advanced Capabilities</h2>
                <p className="text-lg text-white/90 mb-10 leading-relaxed">
                  Our Web GIS platform combines state-of-the-art technology with user-friendly interfaces to deliver
                  comprehensive geospatial solutions for businesses of all sizes.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
                  {capabilities.map((capability, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-6 py-4 rounded-lg hover:bg-white/20 transition-all duration-500"
                    >
                      <ArrowRight className="w-5 h-5 text-white flex-shrink-0" />
                      <span className="text-white font-medium">{capability}</span>
                    </div>
                  ))}
                </div>
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 bg-white text-primary font-bold px-8 py-4 rounded-lg hover:bg-gray-100 transition-all duration-500 hover:shadow-2xl hover:scale-105 group"
                >
                  Get Started
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-500" />
                </Link>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-white/5 rounded-2xl blur-2xl" />
                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png"
                  alt="Web GIS capabilities demonstration"
                  width={500}
                  height={500}
                  className="relative z-10 rounded-xl shadow-2xl hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4 text-center max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-bold text-text-primary mb-6">
              Ready to Transform Your Geospatial Workflow?
            </h2>
            <p className="text-lg text-text-secondary mb-10 leading-relaxed">
              Discover how our Web GIS services can streamline your operations, improve decision-making, and unlock the
              full potential of your spatial data.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-white font-bold px-10 py-4 rounded-lg hover:shadow-2xl hover:shadow-primary/50 transition-all duration-500 hover:scale-105 group"
            >
              Schedule Consultation
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-500" />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
