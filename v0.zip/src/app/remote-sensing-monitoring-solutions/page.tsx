import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Advanced Remote Sensing Solutions",
    content: [
      "Utilizing advanced remote sensing technologies, we deliver accurate environmental data analysis, land cover mapping, and real-time monitoring solutions. Our services harness the power of satellite imagery, aerial photography, and specialized sensors to provide comprehensive insights into environmental changes, land use patterns, and natural resource management.",
      "From multi-spectral analysis to change detection, we help organizations monitor vast areas efficiently, identify trends, and make data-driven decisions for environmental management, agriculture, forestry, and urban planning."
    ]
  },
  {
    title: "Comprehensive Monitoring Services",
    content: [
      "Our remote sensing monitoring solutions provide continuous insights into environmental conditions, vegetation health, water resources, and land use changes. We process and analyze imagery from various satellite platforms and sensors to deliver timely, accurate information tailored to your specific monitoring requirements.",
      "Whether you need crop health monitoring, deforestation detection, urban growth analysis, or disaster assessment, our remote sensing experts deliver actionable intelligence that supports sustainable resource management and informed decision-making."
    ]
  }
];

const features = [
  "Satellite image acquisition and processing",
  "Land cover and land use classification",
  "Vegetation indices and crop monitoring",
  "Change detection and temporal analysis",
  "Environmental impact assessment",
  "Deforestation and forest monitoring",
  "Water body mapping and monitoring",
  "Urban growth and infrastructure monitoring"
];

export default function RemoteSensingMonitoringSolutionsPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Remote Sensing Monitoring Solutions"
          description="Harness advanced remote sensing technologies for accurate environmental analysis, land cover mapping, and real-time monitoring of natural resources."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-19-1-8.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
