import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Precise Cadastral Mapping",
    content: [
      "Our cadastral mapping services leverage advanced GIS and geospatial technologies to create accurate, detailed maps of property boundaries, land parcels, and ownership information. We enhance precise record-keeping and data accessibility for government agencies, municipalities, and private sector clients.",
      "Through modern surveying techniques and digital mapping technologies, we ensure that your cadastral records are up-to-date, legally compliant, and readily accessible for land administration and planning purposes."
    ]
  },
  {
    title: "Comprehensive Land Administration",
    content: [
      "Cadastral mapping is the foundation of effective land management. Our services support property tax assessment, land registration, urban planning, and infrastructure development by providing reliable spatial data on land ownership and boundaries.",
      "We work with the latest surveying equipment and GIS platforms to deliver cadastral maps that meet international standards and local regulatory requirements."
    ]
  }
];

const features = [
  "Property boundary surveying and mapping",
  "Digital cadastral database development",
  "Land parcel digitization and georeferencing",
  "Ownership records integration",
  "Legal boundary documentation",
  "Multi-purpose cadastre systems",
  "Land administration system implementation",
  "Cadastral data maintenance and updates"
];

export default function CadastralMappingServicesPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Cadastral Mapping Service"
          description="Advanced cadastral mapping solutions using GIS and geospatial technology for precise property records and enhanced data accessibility."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
