import { NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

async function refreshAccessToken(refreshToken: string) {
  const tokenUrl = "https://oauth2.googleapis.com/token"
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID || "",
    client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  })

  const res = await fetch(tokenUrl, { method: "POST", body: params })
  return res.json()
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const userId = url.searchParams.get("userId")
    if (!userId) return NextResponse.json({ success: false, message: "userId required" }, { status: 400 })

    const supabase = createAdminClient()
    const { data: profile, error } = await supabase.from("profiles").select("google_refresh_token").eq("id", userId).single()
    if (error || !profile) {
      return NextResponse.json({ success: false, message: "Profile not found" }, { status: 404 })
    }

    const refreshToken = profile.google_refresh_token
    if (!refreshToken) return NextResponse.json({ success: false, message: "User not connected to Google Drive" }, { status: 400 })

    const tokenResp = await refreshAccessToken(refreshToken)
    if (tokenResp.error) {
      console.error("[v0] refresh token error", tokenResp)
      return NextResponse.json({ success: false, message: "Failed to refresh token" }, { status: 500 })
    }

    const accessToken = tokenResp.access_token
    // call Drive API to list files
    // Request more detailed file fields so the client can show size, modified date and owner
    // Support optional parentId to list children of a folder.
    const parentId = url.searchParams.get('parentId')
    const search = url.searchParams.get('search')

    // Build a Drive query (q) by composing parts so we can optionally include
    // parents and a name-based search. This keeps server-side search efficient
    // and leverages Drive's query language (e.g. name contains 'foo').
    const qParts: string[] = []
    if (parentId) {
      qParts.push(`'${parentId}' in parents`)
    } else {
      qParts.push(`'root' in parents`)
    }
    // Always exclude trashed items
    qParts.push('trashed = false')
    // If client supplied a search string, filter by name contains
    if (search && search.trim().length > 0) {
      // Drive query: name contains 'foo' (single quotes inside) - we'll encode later
      qParts.push(`name contains '${search.replace(/'/g, "\\'")}'`)
    }

    const q = encodeURIComponent(qParts.join(' and '))
    const listUrl = `https://www.googleapis.com/drive/v3/files?fields=files(id,name,mimeType,webViewLink,modifiedTime,size,owners(displayName),parents)&pageSize=100&q=${q}`

    const driveRes = await fetch(listUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    })
    const files = await driveRes.json()

    return NextResponse.json({ success: true, files })
  } catch (err) {
    console.error("[v0] google list error", err)
    return NextResponse.json({ success: false, message: "Failed to list files" }, { status: 500 })
  }
}
