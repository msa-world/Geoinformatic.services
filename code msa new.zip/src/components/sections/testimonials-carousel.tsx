"use client";

import * as React from "react";
import Image from "next/image";
import useEmblaCarousel, { type EmblaCarouselType } from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { Quote } from "lucide-react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

type Testimonial = {
  name: string;
  title: string;
  quote: string;
  image: string;
  isLogo: boolean;
};

const testimonialsData: Testimonial[] = [
  {
    name: "Vitaly Sedler",
    title: "Founder, Wpmet",
    quote:
      "The team delivered a high-resolution digitised map, creating a detailed digital twin with remarkable accuracy. They transformed our old scanned maps into an interactive, multi-layered terrain model that exceeded expectations.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/icons/11-293x350-1-1.jpg",
    isLogo: false,
  },
  {
    name: "Survey Of Pakistan",
    title: "Founder, Wpmet",
    quote:
      "Geo Informatic  precise analysis helped AMS Planning identify 50 optimal housing sites in Pakistan, balancing 30+ critical factors while ensuring regulatory compliance and community alignment. Great work done!",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/svgs/Survey_of_Pakistan_Logo_svg-1.png",
    isLogo: true,
  },
  {
    name: "Stephen Flores",
    title: "Founder, Wpmet",
    quote:
      "Geo Informatics Services brought clarity to a very complex project. Their team developed a custom GIS solution that integrated multiple data sources into a single, user-friendly dashboard. We now rely on their GIS tools for ongoing decision-making.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/icons/hanif-sb-e1716957443823-3.jpg",
    isLogo: false,
  },
];

const TestimonialsCarousel = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, align: "start" },
    [Autoplay({ delay: 6000, stopOnInteraction: true })]
  );
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const [scrollSnaps, setScrollSnaps] = React.useState<number[]>([]);
  const titleRef = React.useRef<HTMLHeadingElement>(null);
  const cardsRef = React.useRef<HTMLDivElement>(null);

  const onSelect = React.useCallback((emblaApi: EmblaCarouselType) => {
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, []);

  React.useEffect(() => {
    if (!emblaApi) return;
    setScrollSnaps(emblaApi.scrollSnapList());
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
  }, [emblaApi, onSelect]);

  React.useEffect(() => {
    if (!titleRef.current) return;

    // Text fill animation for title
    const title = titleRef.current;
    const titleHTML = title.innerHTML;
    const plainText = title.textContent || "";
    
    title.innerHTML = `
      <span style="position: relative; display: inline-block;">
        <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; color: transparent; -webkit-text-stroke: 2px #1A1A1A; opacity: 0.2;">${plainText}</span>
        <span class="text-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, currentColor 0%, currentColor 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${titleHTML}</span>
      </span>
    `;

    const fillElement = title.querySelector('.text-fill') as HTMLElement;

    gsap.to(fillElement, {
      backgroundPosition: "0% 0",
      ease: "none",
      scrollTrigger: {
        trigger: title,
        start: "top 70%",
        end: "top 30%",
        scrub: 1,
      },
    });

    // Cards fade in with stagger
    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.testimonial-card');
      gsap.from(cards, {
        y: 80,
        opacity: 0,
        scale: 0.9,
        duration: 1,
        stagger: 0.2,
        ease: "power3.out",
        scrollTrigger: {
          trigger: cardsRef.current,
          start: "top 80%",
          toggleActions: "play none none none",
        },
      });
    }

  }, []);

  const scrollTo = React.useCallback(
    (index: number) => {
      emblaApi?.scrollTo(index);
    },
    [emblaApi]
  );

  return (
    <section className="bg-gradient-to-b from-gray-50 to-white py-20 lg:py-28 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '8s' }} />
        <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-secondary/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '9s', animationDelay: '2s' }} />
        <div className="absolute top-1/2 right-10 w-64 h-64 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '7s', animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 ref={titleRef} className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary tracking-tight">
            What Our <span className="text-[#D97D25] italic">Customers</span> Say
            About Us
          </h2>
          <p className="mt-5 text-base md:text-lg text-text-secondary max-w-2xl mx-auto">
            Hear From Those Who've Mapped Success With Us
          </p>
        </div>

        <div ref={cardsRef} className="overflow-hidden" ref={emblaRef}>
          <div className="flex -ml-4">
            {testimonialsData.map((testimonial, index) => (
              <div
                key={index}
                className="flex-grow-0 flex-shrink-0 basis-full md:basis-1/2 lg:basis-1/3 pl-4"
              >
                <div className="testimonial-card group relative h-full bg-white/95 backdrop-blur-md rounded-2xl overflow-hidden transition-all duration-700 p-8 flex flex-col"
                  style={{
                    boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(199,162,77,0.1)',
                  }}
                >
                  {/* Glowing border effect on hover */}
                  <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
                    style={{
                      background: 'linear-gradient(135deg, rgba(26,188,156,0.4), rgba(199,162,77,0.4), rgba(217,125,37,0.4))',
                      filter: 'blur(20px)',
                      transform: 'scale(1.05)',
                    }}
                  />

                  {/* Card content */}
                  <div className="relative z-10 flex flex-col h-full">
                    <Quote className="absolute top-0 right-0 w-20 h-20 text-blue-400/20 transition-all duration-500 group-hover:text-blue-400/30 group-hover:scale-110" />
                    
                    <div className="flex items-center gap-4 mb-6 relative z-10">
                      <div className="relative w-20 h-20 flex-shrink-0">
                        {/* Avatar glow effect */}
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-secondary/30 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-all duration-500 scale-110" />
                        <div className="relative w-full h-full rounded-full overflow-hidden ring-2 ring-primary/20 group-hover:ring-4 group-hover:ring-primary/40 transition-all duration-500">
                          <Image
                            src={testimonial.image}
                            alt={testimonial.name}
                            width={80}
                            height={80}
                            className={testimonial.isLogo ? 'object-contain w-full h-full p-2 transition-transform duration-500 group-hover:scale-110' : 'object-cover w-full h-full transition-transform duration-500 group-hover:scale-110'}
                          />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-text-primary transition-colors duration-500 group-hover:text-primary">
                          {testimonial.name}
                        </h3>
                        <p className="text-sm text-text-secondary transition-colors duration-500 group-hover:text-secondary">
                          {testimonial.title}
                        </p>
                      </div>
                    </div>

                    <p className="italic text-text-secondary flex-grow leading-relaxed transition-all duration-500 group-hover:text-text-primary/90 relative z-10">
                      "{testimonial.quote}"
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center mt-10 space-x-3">
          {scrollSnaps.map((_, index) => (
            <button
              key={index}
              aria-label={`Go to slide ${index + 1}`}
              onClick={() => scrollTo(index)}
              className={`h-3 rounded-full transition-all duration-500 ${
                index === selectedIndex 
                  ? "bg-gradient-to-r from-primary to-secondary w-12 shadow-lg shadow-primary/30" 
                  : "bg-gray-300 hover:bg-gray-400 w-3 hover:w-6"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;
