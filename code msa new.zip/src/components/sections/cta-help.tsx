"use client";

import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Sparkles } from 'lucide-react';
import Link from 'next/link';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

const CtaHelpSection = () => {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);
  const buttonRef = useRef<HTMLAnchorElement>(null);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!titleRef.current || !textRef.current || !buttonRef.current || !sectionRef.current) return;

    // Text fill animation for title
    const title = titleRef.current;
    const text = title.textContent || "";
    title.innerHTML = `
      <span style="position: relative; display: inline-block;">
        <span style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; color: transparent; -webkit-text-stroke: 2px #D97D25; opacity: 0.3;">${text}</span>
        <span class="text-fill" style="position: relative; display: inline-block; background: linear-gradient(to right, #D97D25 0%, #D97D25 50%, transparent 50%); background-size: 200% 100%; background-position: 100% 0; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">${text}</span>
      </span>
    `;

    const fillElement = title.querySelector('.text-fill') as HTMLElement;

    gsap.to(fillElement, {
      backgroundPosition: "0% 0",
      ease: "none",
      scrollTrigger: {
        trigger: title,
        start: "top 70%",
        end: "top 30%",
        scrub: 1,
      },
    });

    // Scale animation for section with rotation
    gsap.from(sectionRef.current, {
      scale: 0.9,
      opacity: 0,
      rotateX: 10,
      duration: 1.2,
      ease: "power3.out",
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });

    // Text fade in with slide
    gsap.from(textRef.current, {
      y: 40,
      opacity: 0,
      duration: 1,
      delay: 0.3,
      ease: "power3.out",
      scrollTrigger: {
        trigger: textRef.current,
        start: "top 85%",
        toggleActions: "play none none none",
      },
    });

    // Button scale in with bounce
    gsap.from(buttonRef.current, {
      scale: 0.5,
      opacity: 0,
      rotation: -10,
      duration: 0.8,
      delay: 0.6,
      ease: "elastic.out(1, 0.5)",
      scrollTrigger: {
        trigger: buttonRef.current,
        start: "top 85%",
        toggleActions: "play none none none",
      },
    });

  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-28 lg:py-32 bg-no-repeat bg-center overflow-hidden"
      style={{
        backgroundImage: "url('https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/map-13.png')",
        backgroundSize: 'cover',
      }}
    >
      {/* Enhanced glass morphism overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-white/70 to-white/75 backdrop-blur-md" />
      
      {/* Animated shapes with parallax */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-primary/15 to-secondary/15 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '8s' }} />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-to-br from-accent/15 to-primary/15 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '10s', animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-br from-secondary/10 to-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '12s', animationDelay: '4s' }} />
      </div>

      <div className="container mx-auto px-4 text-center flex flex-col items-center relative z-10">
        {/* Decorative icon */}
        <div className="mb-6 relative">
          <Sparkles className="w-16 h-16 text-secondary/60 animate-pulse" style={{ animationDuration: '3s' }} />
        </div>

        <h2 
          ref={titleRef}
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-[#D97D25]"
        >
          How Can We Help You?
        </h2>
        <p 
          ref={textRef}
          className="text-lg md:text-xl leading-relaxed max-w-[900px] mb-10 text-[#1A1A1A]"
        >
          Our experts are ready to guide you in finding the perfect GIS solutions for your needs. Let's discuss your project today
        </p>
        <Link
          ref={buttonRef}
          href="/contact"
          className="group relative inline-flex items-center gap-3 bg-gradient-to-r from-[#B042C6] via-[#9c38b0] to-[#B042C6] bg-size-200 bg-pos-0 text-white font-bold text-lg py-5 px-12 rounded-xl transition-all duration-700 ease-out overflow-hidden shadow-xl hover:shadow-2xl hover:bg-pos-100"
          style={{
            backgroundSize: '200% 100%',
            backgroundPosition: '0% 0%',
          }}
        >
          {/* Glowing effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700"
            style={{
              background: 'radial-gradient(circle at center, rgba(176,66,198,0.6), transparent)',
              filter: 'blur(20px)',
              transform: 'scale(1.2)',
            }}
          />
          
          {/* Animated shine effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
          </div>

          <span className="relative z-10 transition-transform duration-500 group-hover:scale-110">Get A Quote</span>
          <ArrowRight className="w-5 h-5 relative z-10 transition-transform duration-500 group-hover:translate-x-2 group-hover:scale-110" />
          
          {/* Pulsing ring */}
          <div className="absolute inset-0 rounded-xl border-2 border-[#B042C6] opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
        </Link>

        {/* Decorative dots */}
        <div className="mt-12 flex gap-3">
          {[...Array(3)].map((_, i) => (
            <div 
              key={i} 
              className="w-2 h-2 rounded-full bg-gradient-to-r from-primary to-secondary animate-pulse"
              style={{ animationDelay: `${i * 0.2}s`, animationDuration: '2s' }}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CtaHelpSection;
