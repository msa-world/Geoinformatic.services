"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, Send, LogOut, MessageSquare, Upload, X } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

interface UserProfile {
  id: string
  email: string
  full_name: string
  avatar_url: string | null
}

interface Message {
  id: string
  sender_id: string
  recipient_id: string
  content: string
  file_url: string | null
  file_name: string | null
  sender_type: "admin" | "user"
  created_at: string
}

export default function AdminChatPage() {
  const router = useRouter()
  const supabase = createClient()
  const [users, setUsers] = useState<UserProfile[]>([])
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageText, setMessageText] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSending, setIsSending] = useState(false)
  const [error, setError] = useState("")
  const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string } | null>(null)

  useEffect(() => {
    const checkAdmin = () => {
      const adminToken = localStorage.getItem("adminToken")
      const adminUsername = localStorage.getItem("adminUsername")

      if (!adminToken || !adminUsername) {
        router.push("/auth/admin-login")
        return
      }

      fetchUsers()
    }

    checkAdmin()
  }, [])

  // Fetch messages when selected user changes
  useEffect(() => {
    if (selectedUserId) {
      fetchMessages(selectedUserId)
      const channel = supabase
        .channel(`admin-messages-${selectedUserId}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "messages",
            filter: `or(and(sender_id.eq.${selectedUserId},recipient_id.eq.admin),and(sender_id.eq.admin,recipient_id.eq.${selectedUserId}))`,
          },
          () => {
            fetchMessages(selectedUserId)
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    }
  }, [selectedUserId])

  const fetchUsers = async () => {
    try {
      setIsLoading(true)
      const { data, error: fetchError } = await supabase
        .from("profiles")
        .select("id, email, full_name, avatar_url")
        .order("created_at", { ascending: false })

      if (fetchError) throw fetchError
      setUsers(data || [])
      if (data && data.length > 0) {
        setSelectedUserId(data[0].id)
      }
    } catch (err) {
      console.error("[v0] Error fetching users:", err)
      setError("Failed to load users")
    } finally {
      setIsLoading(false)
    }
  }

  const fetchMessages = async (userId: string) => {
    try {
      const { data, error: fetchError } = await supabase
        .from("messages")
        .select("*")
        .or(`and(sender_id.eq.${userId},recipient_id.eq.admin),and(sender_id.eq.admin,recipient_id.eq.${userId})`)
        .order("created_at", { ascending: true })

      if (fetchError) {
        // Fallback: fetch all and filter locally
        const { data: allData } = await supabase.from("messages").select("*").order("created_at", { ascending: true })

        const filtered = (allData || []).filter(
          (msg) =>
            (msg.sender_id === userId && msg.recipient_id === "admin") ||
            (msg.sender_id === "admin" && msg.recipient_id === userId),
        )
        setMessages(filtered)
      } else {
        setMessages(data || [])
      }
    } catch (err) {
      console.error("[v0] Error fetching messages:", err)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    try {
      const fileName = `admin-${Date.now()}-${file.name}`
      const { error: uploadError } = await supabase.storage.from("profiles").upload(`chat/${fileName}`, file)

      if (uploadError) throw uploadError

      const { data } = supabase.storage.from("profiles").getPublicUrl(`chat/${fileName}`)
      setUploadedFile({ name: file.name, url: data.publicUrl })
    } catch (err) {
      console.error("[v0] Upload error:", err)
      setError("Failed to upload file")
    }
  }

  const handleSendMessage = async () => {
    if ((!messageText.trim() && !uploadedFile) || !selectedUserId) return

    try {
      setIsSending(true)

      const { error: insertError } = await supabase.from("messages").insert({
        sender_id: "admin",
        recipient_id: selectedUserId,
        content: messageText || `📎 ${uploadedFile?.name}`,
        file_url: uploadedFile?.url || null,
        file_name: uploadedFile?.name || null,
        sender_type: "admin",
      })

      if (insertError) throw insertError

      // Create notification
      await supabase.from("notifications").insert({
        user_id: selectedUserId,
        message_id: "admin_message",
        is_read: false,
      })

      setMessageText("")
      setUploadedFile(null)
      fetchMessages(selectedUserId)
    } catch (err) {
      console.error("[v0] Error sending message:", err)
      setError("Failed to send message")
    } finally {
      setIsSending(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    localStorage.removeItem("adminUsername")
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center">
        <p className="text-gray-500">Loading chat...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen w-full bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <MessageSquare className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-text-primary">Admin Chat</h1>
              <p className="text-muted-foreground">Send messages to users</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Link href="/admin/users">
              <Button variant="outline">User Management</Button>
            </Link>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="gap-2 bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-6 flex items-start gap-3 p-4 rounded-lg bg-red-50 border border-red-200">
            <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[600px]">
          {/* Users List */}
          <Card className="shadow-lg overflow-hidden flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="text-lg">Users ({users.length})</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-0">
              <div className="space-y-1">
                {users.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => setSelectedUserId(user.id)}
                    className={`w-full text-left px-4 py-3 border-l-4 transition-colors ${
                      selectedUserId === user.id ? "bg-blue-50 border-blue-600" : "border-transparent hover:bg-gray-100"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {user.avatar_url ? (
                        <img
                          src={user.avatar_url || "/placeholder.svg"}
                          alt={user.full_name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">
                          {user.full_name?.charAt(0).toUpperCase() || "U"}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate">{user.full_name || "User"}</p>
                        <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              {users.length === 0 && <p className="text-center py-8 text-muted-foreground text-sm">No users found</p>}
            </CardContent>
          </Card>

          {/* Chat Area */}
          <div className="md:col-span-2 flex flex-col gap-6">
            {selectedUserId ? (
              <>
                {/* Messages */}
                <Card className="shadow-lg flex-1 overflow-hidden flex flex-col">
                  <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender_type === "admin" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-xs px-4 py-3 rounded-lg ${
                            msg.sender_type === "admin"
                              ? "bg-blue-600 text-white rounded-br-none"
                              : "bg-white text-gray-800 border border-gray-200 rounded-bl-none"
                          }`}
                        >
                          <p className="text-sm break-words">{msg.content}</p>
                          {msg.file_url && (
                            <a
                              href={msg.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs underline mt-2 block hover:opacity-80"
                            >
                              📎 {msg.file_name || "Download"}
                            </a>
                          )}
                          <p
                            className={`text-xs mt-1 ${msg.sender_type === "admin" ? "text-blue-100" : "text-gray-500"}`}
                          >
                            {new Date(msg.created_at).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))}
                    {messages.length === 0 && (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-muted-foreground">No messages yet. Start a conversation!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Input */}
                <Card className="shadow-lg">
                  <CardContent className="p-4">
                    {uploadedFile && (
                      <div className="mb-3 p-3 bg-blue-50 rounded-lg flex items-center justify-between">
                        <span className="text-sm">📎 {uploadedFile.name}</span>
                        <button onClick={() => setUploadedFile(null)}>
                          <X className="h-4 w-4 text-gray-500" />
                        </button>
                      </div>
                    )}
                    <div className="flex gap-3">
                      <Textarea
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        placeholder="Type your message..."
                        rows={2}
                        className="resize-none"
                      />
                      <div className="flex flex-col gap-2">
                        <label className="cursor-pointer">
                          <input
                            type="file"
                            onChange={handleFileUpload}
                            className="hidden"
                            accept="image/*,.pdf,.doc,.docx"
                          />
                          <Button type="button" variant="outline" size="icon" className="h-full bg-transparent">
                            <Upload className="h-4 w-4" />
                          </Button>
                        </label>
                        <Button
                          onClick={handleSendMessage}
                          disabled={isSending || (!messageText.trim() && !uploadedFile)}
                          className="gap-2"
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="shadow-lg flex-1 flex items-center justify-center">
                <p className="text-muted-foreground">Select a user to start chatting</p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
