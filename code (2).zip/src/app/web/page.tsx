import HeaderNavigation from "@/components/sections/header-navigation";
import Footer from "@/components/sections/footer";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import Image from "next/image";

const features = [
  {
    title: "Interactive Mapping",
    description:
      "Build responsive, interactive web maps that let users explore spatial data with intuitive controls and fast rendering.",
  },
  {
    title: "Custom Data Integration",
    description:
      "Connect your existing GIS databases, feature services, and APIs for real-time visualization and analysis in the browser.",
  },
  {
    title: "Spatial Analysis On The Web",
    description:
      "Expose common geospatial analyses (buffer, overlay, routing, analytics) directly within web applications for decision-makers.",
  },
  {
    title: "Scalable Architecture",
    description:
      "We design solutions that scale from single-page dashboards to enterprise mapping platforms with secure access control.",
  },
];

export default function WebGISPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Web GIS"
          description="Delivering web-based GIS platforms and interactive mapping applications to visualize, analyze, and share spatial data across your organization."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png"
        />

        {/* Overview */}
        <section className="bg-white py-20 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-text-primary mb-6">What is Web GIS?</h2>
                <p className="text-lg text-text-secondary leading-relaxed mb-4">
                  Web GIS brings the power of geographic information systems to the browser. We build interactive mapping interfaces,
                  dashboards, and spatially-enabled web applications that let users visualize and interact with complex spatial datasets
                  without specialized desktop software.
                </p>
                <p className="text-lg text-text-secondary leading-relaxed">
                  Our Web GIS solutions focus on usability, performance, and secure data access — enabling stakeholders to explore
                  insights and make decisions using up-to-date spatial information.
                </p>
              </div>
              <div className="relative h-[360px] lg:h-[440px] rounded-xl overflow-hidden shadow-2xl">
                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-13-5.png"
                  alt="Web GIS Example"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="bg-gradient-to-r from-[#D9A561] to-[#7FA89A] py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">Key Capabilities</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((f, i) => (
                <div key={i} className="bg-white/10 p-6 rounded-xl backdrop-blur-sm border border-white/10">
                  <h3 className="text-xl font-semibold text-white mb-3">{f.title}</h3>
                  <p className="text-white/90 leading-relaxed">{f.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Example integrations / Tech stack */}
        <section className="bg-white py-20 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-text-primary">Integrations & Technologies</h2>
              <p className="text-lg text-text-secondary max-w-3xl mx-auto mt-4">
                We integrate open-source and commercial GIS components (Leaflet, Mapbox GL, OpenLayers, Esri ArcGIS JS) and
                backend services (PostGIS, GeoServer, Vector Tiles, feature services) to tailor solutions to your needs.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6">
              {[
                "/logos/leaflet.svg",
                "/logos/mapbox.svg",
                "/logos/openlayers.svg",
                "/logos/esri.svg",
                "/logos/postgis.svg",
              ].map((logo, idx) => (
                <div key={idx} className="w-32 h-16 bg-gray-50 rounded flex items-center justify-center p-4 shadow-sm">
                  <span className="text-sm text-text-secondary">{logo.replace("/logos/", "").replace('.svg','').toUpperCase()}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Live Portal Preview */}
        <section className="bg-gray-50 py-12 lg:py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-text-primary text-center mb-6">Live Portal Preview</h2>
            <p className="text-center text-text-secondary mb-6">Interactive preview of a sample Web GIS portal. If it doesn't load here the remote site may block embedding — open in a new tab to view full functionality.</p>

            <div className="rounded-xl overflow-hidden shadow-2xl border border-gray-200">
              <div className="w-full h-[600px] md:h-[800px]">
                <iframe
                  src="https://islamabad-portal.vercel.app/"
                  title="Islamabad Portal Live Preview"
                  className="w-full h-full"
                  frameBorder="0"
                  allowFullScreen
                  loading="lazy"
                />
              </div>
            </div>

            <div className="text-center mt-4">
              <a href="https://islamabad-portal.vercel.app/" target="_blank" rel="noopener noreferrer" className="text-primary font-semibold underline">Open full portal in a new tab</a>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-gradient-to-r from-[#D9A561] to-[#7FA89A] py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to build your Web GIS?</h2>
            <p className="text-xl text-white/95 mb-8 max-w-2xl mx-auto">We design performant, maintainable, and secure web GIS platforms tailored to your workflows.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact"
                className="inline-block bg-white/95 backdrop-blur-md text-primary font-semibold px-10 py-4 rounded-full hover:shadow-lg transition-all hover:scale-105"
              >
                Contact Us
              </a>
              <a
                href="/projects"
                className="inline-block border-2 border-white/30 text-white font-semibold px-10 py-4 rounded-full hover:bg-white/10 transition-all"
              >
                View Projects
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
