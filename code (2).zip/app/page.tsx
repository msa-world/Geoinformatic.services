"use client"

import { AlertDialog } from "../src/components/ui/alert-dialog"

export default function SyntheticV0PageForDeployment() {
  return <AlertDialog />
}