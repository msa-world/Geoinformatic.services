"use client"

import React from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"
import useEmblaCarousel from "embla-carousel-react"

const testimonialsData = [
  {
    name: "Vitaly Sedler",
    title: "Founder, Wpmet",
    quote:
      "The team delivered a high-resolution digitised map, creating a detailed digital twin with remarkable accuracy. They transformed our old scanned maps into an interactive, multi-layered terrain model that exceeded expectations.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/icons/11-293x350-1-1.jpg",
  },
  {
    name: "Survey Of Pakistan",
    title: "Government Agency",
    quote:
      "Geo Informatic precise analysis helped AMS Planning identify 50 optimal housing sites in Pakistan, balancing 30+ critical factors while ensuring regulatory compliance and community alignment. Great work done!",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/svgs/Survey_of_Pakistan_Logo_svg-1.png",
  },
  {
    name: "Stephen Flores",
    title: "Founder, Wpmet",
    quote:
      "Geo Informatics Services brought clarity to a very complex project. Their team developed a custom GIS solution that integrated multiple data sources into a single, user-friendly dashboard. We now rely on their GIS tools for ongoing decision-making.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/icons/hanif-sb-e1716957443823-3.jpg",
  },
]

const TestimonialsCarousel = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: "start" })

  const scrollPrev = React.useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev()
  }, [emblaApi])

  const scrollNext = React.useCallback(() => {
    if (emblaApi) emblaApi.scrollNext()
  }, [emblaApi])

  return (
    <section className="bg-white py-24 sm:py-32 relative border-t border-gray-200 overflow-hidden">
      <div
        className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-40"
        aria-hidden="true"
      />
      <div className="max-w-[1440px] mx-auto px-6 md:px-20 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-8 gap-y-4 items-end">
          <div className="lg:col-span-5">
            <h2 className="text-4xl md:text-5xl font-normal text-gray-900 tracking-tight leading-tight">
              What Our Customers
              <br />
              <span className="text-[#D97D25] italic">Say About Us</span>
            </h2>
          </div>
          <div className="lg:col-span-7">
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
              <p className="text-base text-gray-600 leading-6 max-w-lg">
                Hear from those who have mapped success with us. Our clients trust us to deliver precise, actionable
                geospatial solutions.
              </p>
              <div className="hidden lg:flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={scrollPrev}
                  className="rounded-full bg-gray-100 p-2.5 text-gray-900 hover:bg-gray-200 transition-colors"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={scrollNext}
                  className="rounded-full bg-gray-100 p-2.5 text-gray-900 hover:bg-gray-200 transition-colors"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 lg:mt-20">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex -ml-4">
              {testimonialsData.map((testimonial) => (
                <div className="min-w-0 flex-[0_0_100%] pl-4" key={testimonial.name}>
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-8 gap-y-6 items-center">
                    <div className="lg:col-span-5 order-2 lg:order-1">
                      <Quote className="w-10 h-10 text-[#D97D25]/20 mb-4" />
                      <h3 className="text-xl font-medium text-gray-900 leading-7">
                        {testimonial.name}
                        <span className="block text-sm text-gray-500 font-normal mt-1">{testimonial.title}</span>
                      </h3>
                      <p className="mt-4 text-base text-gray-600 leading-relaxed max-w-[450px]">
                        "{testimonial.quote}"
                      </p>
                    </div>
                    <div className="lg:col-span-7 order-1 lg:order-2">
                      <div className="relative aspect-[16/10] max-w-2xl mx-auto rounded-xl overflow-hidden shadow-xl">
                        <Image
                          src={testimonial.image || "/placeholder.svg"}
                          alt={`Testimonial from ${testimonial.name}`}
                          fill
                          className="object-cover transition-transform duration-500 hover:scale-105"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 flex lg:hidden items-center justify-center gap-4">
          <button
            onClick={scrollPrev}
            className="rounded-full bg-gray-100 p-2.5 text-gray-900 hover:bg-gray-200 transition-colors"
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={scrollNext}
            className="rounded-full bg-gray-100 p-2.5 text-gray-900 hover:bg-gray-200 transition-colors"
            aria-label="Next testimonial"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  )
}

export default TestimonialsCarousel
