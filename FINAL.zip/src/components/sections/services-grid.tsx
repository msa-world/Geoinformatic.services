"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

interface Service {
  title: string
  description: string
  imageUrl: string
  link: string
}

const services: Service[] = [
  {
    title: "GIS Consultant Services",
    description:
      "With a team of GIS professionals, surveyors we combine technical precision, on-ground experience and latest geospatial technologies.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-10-3.png",
    link: "/gis-consultant-services",
  },
  {
    title: "Cadastral Mapping Service",
    description:
      "Implemented through advanced technology like GIS, Geospatial, cadastral mapping enhances precise record-keeping and data accessibility.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-12-4.png",
    link: "/cadastral-mapping-services",
  },
  {
    title: "Spatial Data Services",
    description:
      "At geo informatic, our job is to make complex data useful. Our mapping and spatial analysis services are built to support your goals and needs.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-13-5.png",
    link: "/spatial-data-services",
  },
  {
    title: "Topographical Surveying Services",
    description:
      "We provide Topographical Surveying Services including LIDAR 3D mapping, Building Information Modeling, Revit modeling, 3D laser scanning, 3D imaging etc.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-20-1-6.png",
    link: "/topographical-surveying-services",
  },
  {
    title: "Georeferencing & Digitization Services",
    description:
      "Stay ahead with accurate, digitised data you can trust. Let us GIS Navigator help you fix gaps, reduce delays, and confidently move your projects forward.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-18-1-7.png",
    link: "/georeferencing-digitization-services",
  },
  {
    title: "Remote Sensing Monitoring Solutions",
    description:
      "Utilizing advanced remote sensing technologies, we deliver accurate environmental data analysis, land cover mapping, and real-time monitoring.",
    imageUrl:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-19-1-8.png",
    link: "/remote-sensing-monitoring-solutions",
  },
]

const ServicesGrid = () => {
  const [activeIndex, setActiveIndex] = useState(0)
  const featureRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0", 10)
            setActiveIndex(index)
          }
        })
      },
      {
        rootMargin: "-50% 0px -50% 0px",
        threshold: 0,
      },
    )

    const currentRefs = featureRefs.current
    currentRefs.forEach((ref) => {
      if (ref) observer.observe(ref)
    })

    return () => {
      currentRefs.forEach((ref) => {
        if (ref) observer.unobserve(ref)
      })
    }
  }, [])

  return (
    <section className="bg-background-primary py-24 md:py-32 relative">
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(218, 220, 224, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(218, 220, 224, 0.3) 1px, transparent 1px)",
          backgroundSize: "36px 36px",
        }}
      />
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="mb-16 md:mb-24 text-center md:text-left">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">Our Services</h2>
          <div className="h-1.5 w-24 bg-[#D97D25] mt-4 rounded-full mx-auto md:mx-0" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 md:gap-x-16">
          <div className="hidden md:block md:col-span-4">
            <div className="sticky top-32 space-y-12">
              <ul className="space-y-10">
                {services.map((service, index) => (
                  <li key={service.title}>
                    <motion.h3
                      className="font-display text-2xl font-bold cursor-pointer"
                      animate={{
                        color: activeIndex === index ? "#000000" : "#9CA3AF",
                        fontWeight: activeIndex === index ? 600 : 400,
                      }}
                      transition={{ duration: 0.3 }}
                      onClick={() => {
                        featureRefs.current[index]?.scrollIntoView({ behavior: "smooth", block: "center" })
                      }}
                    >
                      {service.title}
                    </motion.h3>
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{
                        opacity: activeIndex === index ? 1 : 0,
                        height: activeIndex === index ? "auto" : 0,
                      }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <p className="text-gray-600 mt-2 text-base leading-relaxed">{service.description}</p>
                      <Link
                        href={service.link}
                        className="inline-flex items-center gap-2 mt-4 text-primary font-medium hover:text-primary/80 transition-colors group"
                      >
                        Learn more <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="md:col-span-7 md:col-start-6 space-y-24">
            {services.map((service, index) => (
              <div key={index} ref={(el) => (featureRefs.current[index] = el)} data-index={index} className="space-y-4">
                <div className="relative w-full aspect-video rounded-2xl overflow-hidden shadow-lg">
                  <Image
                    src={service.imageUrl || "/placeholder.svg"}
                    alt={service.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                  />
                </div>
                <div className="md:hidden pt-2">
                  <h3 className="text-xl font-bold text-gray-900">{service.title}</h3>
                  <p className="text-gray-600 mt-2">{service.description}</p>
                  <Link
                    href={service.link}
                    className="inline-flex items-center gap-2 mt-4 text-primary font-medium hover:text-primary/80 transition-colors"
                  >
                    Learn more <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ServicesGrid
