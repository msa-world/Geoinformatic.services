import { NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId } = body || {}
    if (!userId) return NextResponse.json({ success: false, message: "userId required" }, { status: 400 })

    const supabase = createAdminClient()
    const { data: profile, error } = await supabase.from('profiles').select('google_refresh_token').eq('id', userId).single()
    if (error || !profile) return NextResponse.json({ success: false, message: 'Profile not found' }, { status: 404 })

    const refreshToken = profile.google_refresh_token
    if (refreshToken) {
      // Revoke token at Google
      try {
        const revokeUrl = 'https://oauth2.googleapis.com/revoke'
        const params = new URLSearchParams({ token: refreshToken })
        await fetch(revokeUrl, { method: 'POST', body: params })
      } catch (err) {
        console.error('[v0] revoke error', err)
        // continue to clear DB even if revoke fails
      }
    }

    // Clear stored tokens in profiles
    const { error: updErr } = await supabase.from('profiles').update({
      google_refresh_token: null,
      google_access_token: null,
      google_connected_at: null,
      google_scope: null,
    }).eq('id', userId)

    if (updErr) {
      console.error('[v0] clear tokens error', updErr)
      return NextResponse.json({ success: false, message: 'Failed to clear tokens' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('[v0] disconnect error', err)
    return NextResponse.json({ success: false, message: 'Failed to disconnect' }, { status: 500 })
  }
}
