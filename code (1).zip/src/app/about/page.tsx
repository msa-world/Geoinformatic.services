import HeaderNavigation from "@/components/sections/header-navigation";
import Footer from "@/components/sections/footer";
import Image from "next/image";
import { Target, Users, Award, TrendingUp } from "lucide-react";

const stats = [
  { icon: Award, label: "Years of Experience", value: "5+" },
  { icon: Users, label: "Projects Completed", value: "10+" },
  { icon: TrendingUp, label: "Satisfied Customers", value: "15+" },
  { icon: Target, label: "Area Analyzed", value: "5000+ km²" },
];

const values = [
  {
    title: "Technical Excellence",
    description: "We leverage cutting-edge GIS technologies and methodologies to deliver precise, reliable geospatial solutions that meet the highest industry standards.",
    icon: Award
  },
  {
    title: "Client-Focused Approach",
    description: "Your success is our priority. We work closely with clients to understand their unique challenges and deliver tailored solutions that exceed expectations.",
    icon: Users
  },
  {
    title: "Innovation & Expertise",
    description: "Our team combines deep technical expertise with innovative thinking to solve complex geospatial challenges and unlock new possibilities.",
    icon: TrendingUp
  },
  {
    title: "Quality & Precision",
    description: "We maintain rigorous quality control standards throughout every project, ensuring accuracy, reliability, and actionable insights.",
    icon: Target
  },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-[#C7A24D] via-[#D97D25] to-[#7FA89A] py-24 lg:py-32">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container relative mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              About Geo-Informatic
            </h1>
            <p className="text-xl md:text-2xl text-white/95 max-w-3xl mx-auto">
              Leading provider of innovative GIS solutions, transforming spatial data into strategic insights
            </p>
          </div>
        </section>

        {/* Company Overview */}
        <section className="bg-white py-20 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-text-primary mb-6">
                  Who We Are
                </h2>
                <div className="space-y-4 text-lg text-text-secondary leading-relaxed">
                  <p>
                    At <strong className="text-text-primary">Geo Informatics Services</strong>, we specialize in providing high-quality Geographic Information System (GIS) solutions tailored to meet the evolving needs of modern industries.
                  </p>
                  <p>
                    Our team consists of experienced GIS professionals, analysts, and engineers dedicated to delivering reliable, cost-effective, and innovative geospatial solutions. We combine technical precision with on-ground experience and the latest geospatial technologies.
                  </p>
                  <p>
                    From mapping and surveying to spatial analysis and data visualization, we bring your data to life through powerful geospatial intelligence that drives better decision-making across urban planning, environmental monitoring, infrastructure development, and beyond.
                  </p>
                </div>
              </div>
              <div className="relative h-[400px] lg:h-[500px] rounded-xl overflow-hidden shadow-2xl">
                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-1560-x-1440-px-1560-x-740-px-2-scaled-10.png"
                  alt="GIS Analysis"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="bg-gradient-to-r from-[#D9A561] to-[#7FA89A] py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-16">
              Our Impact in Numbers
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                      {stat.value}
                    </div>
                    <div className="text-white/90 font-medium">
                      {stat.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="bg-white py-20 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-text-primary mb-6">
                Our Core Values
              </h2>
              <p className="text-xl text-text-secondary max-w-3xl mx-auto">
                The principles that guide everything we do and drive our commitment to excellence
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <div
                    key={index}
                    className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
                  >
                    <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold text-text-primary mb-4">
                      {value.title}
                    </h3>
                    <p className="text-lg text-text-secondary leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="bg-gradient-to-b from-[#D9A561] to-[#7FA89A] py-20 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm p-10 rounded-xl">
                <h3 className="text-3xl font-bold text-white mb-6">Our Mission</h3>
                <p className="text-white/95 text-lg leading-relaxed">
                  To empower organizations with innovative geospatial solutions that transform complex spatial data into actionable insights, enabling better decision-making and sustainable development.
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-10 rounded-xl">
                <h3 className="text-3xl font-bold text-white mb-6">Our Vision</h3>
                <p className="text-white/95 text-lg leading-relaxed">
                  To be the leading provider of GIS solutions, recognized for technical excellence, innovation, and our commitment to helping clients unlock the full potential of geospatial technology.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-white py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-text-primary mb-6">
              Ready to Work With Us?
            </h2>
            <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
              Discover how our GIS expertise can help you achieve your goals and transform your spatial data into strategic advantages.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact"
                className="inline-block bg-gradient-to-r from-[#C7A24D] to-[#D97D25] text-white font-semibold px-10 py-4 rounded-full hover:shadow-lg transition-all hover:scale-105"
              >
                Contact Us
              </a>
              <a
                href="/projects"
                className="inline-block border-2 border-primary text-primary font-semibold px-10 py-4 rounded-full hover:bg-primary hover:text-white transition-all"
              >
                View Projects
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
