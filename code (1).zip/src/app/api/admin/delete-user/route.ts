import { createAdminClient } from "@/lib/supabase/admin"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const adminToken = request.headers.get("authorization")?.split(" ")[1]
    const { userId } = await request.json()

    // Verify admin token (in production, validate properly)
    if (!adminToken || !userId) {
      return NextResponse.json({ message: "Unauthorized or missing user ID" }, { status: 401 })
    }

    const adminSupabase = createAdminClient()

    // Delete user's profile
    const { error: profileError } = await adminSupabase.from("profiles").delete().eq("id", userId)

    if (profileError) throw profileError

    // Delete auth user
    const { error: authError } = await adminSupabase.auth.admin.deleteUser(userId)

    if (authError) throw authError

    return NextResponse.json({ message: "User deleted successfully" }, { status: 200 })
  } catch (error) {
    console.error("[v0] Delete user error:", error)
    return NextResponse.json({ message: "Failed to delete user" }, { status: 500 })
  }
}
