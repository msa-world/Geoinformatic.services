"use client"

import * as React from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { LogOut, Settings, User, FileText, MessageSquare, HardDrive } from "lucide-react"

interface UserMenuProps {
  user: {
    id: string
    email: string
    name?: string
  }
}

export default function UserMenu({ user }: UserMenuProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = React.useState(false)
  const [avatarUrl, setAvatarUrl] = React.useState<string | null>(null)

  React.useEffect(() => {
    const fetchProfileImage = async () => {
      try {
        const supabase = createClient()
        const { data: profileData } = await supabase.from("profiles").select("avatar_url").eq("id", user.id).single()

        if (profileData?.avatar_url) {
          setAvatarUrl(profileData.avatar_url)
        }
      } catch (error) {
        console.error("[v0] Error fetching profile image:", error)
      }
    }

    fetchProfileImage()
  }, [user.id])

  const handleLogout = async () => {
    setIsLoading(true)
    try {
      const supabase = createClient()
      await supabase.auth.signOut()
      router.push("/")
      router.refresh()
    } catch (error) {
      console.error("[v0] Logout error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getInitials = (email: string, name?: string) => {
    if (name) {
      return name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
    }
    return email.charAt(0).toUpperCase()
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-9 w-9 rounded-full p-0">
            <Avatar className="h-9 w-9">
              <AvatarImage src={avatarUrl || "/placeholder.svg?height=36&width=36"} alt={user.email} />
              <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                {getInitials(user.email, user.name)}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>

        {/* White menu with neon glow + slide-down animation */}
        <DropdownMenuContent
          className="w-60 bg-white text-slate-900 border border-slate-200 backdrop-blur-sm rounded-lg shadow-lg neon-menu p-1 overflow-hidden"
          align="end"
          forceMount
        >
          <DropdownMenuLabel className="font-normal bg-transparent py-3 px-4 rounded-t-lg">
            <div className="flex flex-col space-y-0.5">
              <p className="text-sm font-semibold text-slate-900">{user.name || user.email}</p>
              <p className="text-xs text-slate-500">{user.email}</p>
            </div>
          </DropdownMenuLabel>

          <DropdownMenuSeparator className="my-1 border-slate-100" />

          <DropdownMenuItem asChild className="menu-item rounded-md">
            <Link href="/profile" className="cursor-pointer group flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300">
              <User className="icon h-4 w-4 text-slate-700 transition-transform duration-300" />
              <span className="text-sm">Profile</span>
            </Link>
          </DropdownMenuItem>

          <DropdownMenuItem asChild className="menu-item rounded-md">
            <Link href="/profile/documents" className="cursor-pointer group flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300">
              <FileText className="icon h-4 w-4 text-slate-700 transition-transform duration-300" />
              <span className="text-sm">Documents</span>
            </Link>
          </DropdownMenuItem>

          <DropdownMenuItem asChild className="menu-item rounded-md">
            <Link href="/profile/chat" className="cursor-pointer group flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300">
              <MessageSquare className="icon h-4 w-4 text-slate-700 transition-transform duration-300" />
              <span className="text-sm">Chat with Admin</span>
            </Link>
          </DropdownMenuItem>

          <DropdownMenuItem asChild className="menu-item rounded-md">
            <Link href="/profile/settings" className="cursor-pointer group flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300">
              <Settings className="icon h-4 w-4 text-slate-700 transition-transform duration-300" />
              <span className="text-sm">Settings</span>
            </Link>
          </DropdownMenuItem>

          <DropdownMenuSeparator className="my-1 border-slate-100" />

          {/* Neon Connect Drive button */}
          <DropdownMenuItem asChild className="menu-item rounded-md">
            <Link
              href="/profile/drive"
              className="group relative flex items-center gap-2 px-3 py-2 rounded-md overflow-hidden transition-all duration-300"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-cyan-400/10 via-blue-400/8 to-purple-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              <HardDrive className="icon h-4 w-4 text-cyan-600 transition-transform duration-300" />
              <span className="text-sm font-semibold text-cyan-700">Connect Drive</span>
            </Link>
          </DropdownMenuItem>

          <DropdownMenuSeparator className="my-1 border-slate-100" />

          <DropdownMenuItem
            onClick={handleLogout}
            disabled={isLoading}
            className="menu-item rounded-md"
          >
            <div className="flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 cursor-pointer text-red-600">
              <LogOut className="icon h-4 w-4 transition-transform duration-300" />
              <span className="text-sm">{isLoading ? "Signing out..." : "Sign Out"}</span>
            </div>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Component-scoped styles for neon glow and animations */}
      <style jsx>{`
        .neon-menu {
          --neon-cyan: 0 200 255;
          --neon-purple: 160 90 255;
          --neon-blue: 0 120 255;
          animation: slideDown 260ms cubic-bezier(.22,.9,.29,1);
        }

        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-6px) scale(.995); filter: blur(2px); }
          to   { opacity: 1; transform: translateY(0) scale(1); filter: none; }
        }

        /* menu items entrance */
        .menu-item {
          transform-origin: left center;
          animation: itemIn 360ms cubic-bezier(.22,.9,.29,1);
        }
        @keyframes itemIn {
          from { opacity: 0; transform: translateX(-8px); }
          to   { opacity: 1; transform: translateX(0); }
        }

        /* icon neon hover and subtle motion */
        .icon {
          transition: transform 180ms ease, filter 220ms ease, color 220ms ease;
          will-change: transform, filter;
        }

        /* hover states for interactive feel */
        .menu-item:hover .icon,
        .menu-item:focus .icon,
        .group:hover .icon {
          transform: translateX(2px) scale(1.05);
          filter: drop-shadow(0 6px 12px rgba(var(--neon-blue),0.07)) drop-shadow(0 0 8px rgba(var(--neon-cyan),0.09));
        }

        /* special neon style for Connect Drive */
        a[href$="/profile/drive"] .icon {
          color: rgb(var(--neon-blue));
        }
        a[href$="/profile/drive"]:hover,
        a[href$="/profile/drive"]:focus {
          box-shadow: 0 6px 30px rgba(var(--neon-cyan),0.08), 0 0 18px rgba(var(--neon-purple),0.06);
        }
        a[href$="/profile/drive"]:hover .icon {
          filter: drop-shadow(0 8px 18px rgba(var(--neon-cyan),0.14)) drop-shadow(0 0 12px rgba(var(--neon-purple),0.08));
          transform: translateX(3px) scale(1.08);
        }

        /* subtle hover background for items */
        .menu-item > a:hover,
        .menu-item > a:focus,
        .menu-item:hover > div,
        .menu-item:focus > div {
          background: linear-gradient(90deg, rgba(14,165,233,0.03), rgba(99,102,241,0.02));
          backdrop-filter: blur(2px);
        }

        /* accessibility: focus outline */
        .menu-item:focus-within,
        .menu-item:focus {
          outline: 2px solid rgba(var(--neon-blue),0.06);
          outline-offset: 2px;
        }
      `}</style>
    </>
  )
}
