"use client"

import type React from "react"
import { useRef } from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, Send, LogOut, Upload, X, Menu, ChevronLeft, Search } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

interface UserProfile {
  id: string
  email: string
  full_name: string
  avatar_url: string | null
  unread_count: number
}

interface Message {
  id: string
  sender_id: string
  recipient_id: string
  content: string
  file_url: string | null
  file_name: string | null
  sender_type: "admin" | "user"
  created_at: string
}

export default function AdminChatPage() {
  const router = useRouter()
  const supabase = createClient()
  const [users, setUsers] = useState<UserProfile[]>([])
  const [filteredUsers, setFilteredUsers] = useState<UserProfile[]>([])
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageText, setMessageText] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSending, setIsSending] = useState(false)
  const [error, setError] = useState("")
  const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string } | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const messageContainerRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const checkAdmin = () => {
      const adminToken = localStorage.getItem("adminToken")
      const adminUsername = localStorage.getItem("adminUsername")

      if (!adminToken || !adminUsername) {
        router.push("/auth/admin-login")
        return
      }

      fetchUsers()
    }

    checkAdmin()
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredUsers(users)
    } else {
      const query = searchQuery.toLowerCase()
      setFilteredUsers(
        users.filter(
          (user) => user.full_name.toLowerCase().includes(query) || user.email.toLowerCase().includes(query),
        ),
      )
    }
  }, [searchQuery, users])

  useEffect(() => {
    if (selectedUserId) {
      fetchMessages(selectedUserId)
      const channel = supabase
        .channel(`admin-messages-${selectedUserId}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "messages",
            filter: `or(and(sender_id.eq.${selectedUserId},recipient_id.eq.admin),and(sender_id.eq.admin,recipient_id.eq.${selectedUserId}))`,
          },
          () => {
            fetchMessages(selectedUserId)
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    }
  }, [selectedUserId])

  const fetchUsers = async () => {
    try {
      setIsLoading(true)
      const adminToken = localStorage.getItem("adminToken")
      const response = await fetch("/api/admin/get-users", {
        headers: {
          "x-admin-token": adminToken || "",
        },
      })

      if (!response.ok) {
        throw new Error("Failed to fetch users")
      }

      const { users: data } = await response.json()
      setUsers(data || [])
      setFilteredUsers(data || [])
      if (data && data.length > 0 && !selectedUserId) {
        setSelectedUserId(data[0].id)
      }
    } catch (err) {
      console.error("[v0] Error fetching users:", err)
      setError("Failed to load users.")
    } finally {
      setIsLoading(false)
    }
  }

  const fetchMessages = async (userId: string) => {
    try {
      const { data, error: fetchError } = await supabase
        .from("messages")
        .select("*")
        .or(`and(sender_id.eq.${userId},recipient_id.eq.admin),and(sender_id.eq.admin,recipient_id.eq.${userId})`)
        .order("created_at", { ascending: true })

      if (fetchError) {
        console.error("[v0] Query error:", fetchError)
        // Fallback: fetch all messages and filter locally
        const { data: allData } = await supabase.from("messages").select("*").order("created_at", { ascending: true })

        const filtered = (allData || []).filter(
          (msg) =>
            (msg.sender_id === userId && msg.recipient_id === "admin") ||
            (msg.sender_id === "admin" && msg.recipient_id === userId),
        )
        setMessages(filtered)
      } else {
        setMessages(data || [])
      }
    } catch (err) {
      console.error("[v0] Error fetching messages:", err)
      setError("Failed to load messages")
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    try {
      const fileName = `admin-${Date.now()}-${file.name}`
      const { error: uploadError } = await supabase.storage.from("profiles").upload(`chat/${fileName}`, file)

      if (uploadError) throw uploadError

      const { data } = supabase.storage.from("profiles").getPublicUrl(`chat/${fileName}`)
      setUploadedFile({ name: file.name, url: data.publicUrl })
      setError("")
    } catch (err) {
      console.error("[v0] Upload error:", err)
      setError("Failed to upload file")
    }
  }

  const handleSendMessage = async () => {
    if ((!messageText.trim() && !uploadedFile) || !selectedUserId) return

    try {
      setIsSending(true)
      const adminToken = localStorage.getItem("adminToken")

      const response = await fetch("/api/admin/send-message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-token": adminToken || "",
        },
        body: JSON.stringify({
          userId: selectedUserId,
          message: messageText || `📎 ${uploadedFile?.name}`,
          file_url: uploadedFile?.url || null,
          file_name: uploadedFile?.name || null,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        setError(data.message || "Failed to send message")
        return
      }

      setMessageText("")
      setUploadedFile(null)
      setError("")
      fetchMessages(selectedUserId)
    } catch (err) {
      console.error("[v0] Error sending message:", err)
      setError("Failed to send message")
    } finally {
      setIsSending(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    localStorage.removeItem("adminUsername")
    router.push("/")
  }

  useEffect(() => {
    if (messageContainerRef.current) {
      messageContainerRef.current.scrollTop = messageContainerRef.current.scrollHeight
    }
  }, [messages])

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
        <p className="text-gray-500">Loading chat...</p>
      </div>
    )
  }

  const selectedUser = users.find((u) => u.id === selectedUserId)

  return (
    <div className="min-h-screen w-full bg-gray-50 flex flex-col">
      {/* Top Navigation Bar */}
      <div className="bg-white border-b sticky top-0 z-20 shadow-sm">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden p-2 hover:bg-gray-100 rounded-lg">
              <Menu className="h-5 w-5" />
            </button>
            <Link href="/admin/dashboard" className="text-lg font-bold text-primary hover:opacity-80">
              Admin Chat
            </Link>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="gap-2 bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>
      </div>

      {/* Main Chat Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Users List */}
        <div
          className={`${
            sidebarOpen ? "w-full" : "hidden"
          } md:w-80 bg-white border-r border-gray-200 flex flex-col transition-all duration-300 z-10 md:z-0 md:relative md:block`}
        >
          {/* Search Bar */}
          <div className="p-4 border-b bg-white">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          {/* Users List */}
          <div className="flex-1 overflow-y-auto">
            {filteredUsers.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                {searchQuery ? "No users found" : "No users available"}
              </div>
            ) : (
              <div className="space-y-0">
                {filteredUsers.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => {
                      setSelectedUserId(user.id)
                      setSidebarOpen(false)
                    }}
                    className={`w-full text-left px-4 py-3 border-l-4 transition-all hover:bg-gray-50 ${
                      selectedUserId === user.id
                        ? "bg-blue-50 border-blue-600"
                        : "border-transparent hover:border-gray-300"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {user.avatar_url ? (
                        <img
                          src={user.avatar_url || "/placeholder.svg"}
                          alt={user.full_name}
                          className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                          {user.full_name?.charAt(0).toUpperCase() || "U"}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate text-gray-900">{user.full_name || "User"}</p>
                        <p className="text-xs text-gray-500 truncate">{user.email}</p>
                      </div>
                      {user.unread_count > 0 && (
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full flex-shrink-0 font-semibold">
                          {user.unread_count}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Main Chat Area */}
        <div className={`${selectedUserId ? "flex" : "hidden"} md:flex md:flex-1 flex-col w-full`}>
          {selectedUser ? (
            <>
              {/* Chat Header */}
              <div className="bg-white border-b p-4 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                  <button onClick={() => setSidebarOpen(true)} className="md:hidden p-1 hover:bg-gray-100 rounded">
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  {selectedUser.avatar_url ? (
                    <img
                      src={selectedUser.avatar_url || "/placeholder.svg"}
                      alt={selectedUser.full_name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                      {selectedUser.full_name?.charAt(0).toUpperCase() || "U"}
                    </div>
                  )}
                  <div>
                    <h2 className="font-semibold text-gray-900">{selectedUser.full_name}</h2>
                    <p className="text-xs text-gray-500">{selectedUser.email}</p>
                  </div>
                </div>
                <Link href={`/admin/users/${selectedUserId}`}>
                  <Button variant="outline" size="sm">
                    View Profile
                  </Button>
                </Link>
              </div>

              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50" ref={messageContainerRef}>
                {error && (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-red-50 border border-red-200 sticky top-0">
                    <AlertCircle className="h-4 w-4 text-red-600 flex-shrink-0" />
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground text-sm">No messages yet. Start a conversation!</p>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender_type === "admin" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg shadow-sm ${
                          msg.sender_type === "admin"
                            ? "bg-blue-600 text-white rounded-br-none"
                            : "bg-white text-gray-800 border border-gray-200 rounded-bl-none"
                        }`}
                      >
                        <p className="text-sm break-words">{msg.content}</p>
                        {msg.file_url && (
                          <a
                            href={msg.file_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`text-xs underline mt-2 block hover:opacity-80 ${
                              msg.sender_type === "admin" ? "text-blue-100" : "text-blue-600"
                            }`}
                          >
                            📎 {msg.file_name || "Download"}
                          </a>
                        )}
                        <p
                          className={`text-xs mt-1 ${msg.sender_type === "admin" ? "text-blue-100" : "text-gray-500"}`}
                        >
                          {new Date(msg.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Input Area */}
              <div className="bg-white border-t p-4 space-y-3 shadow-sm">
                {uploadedFile && (
                  <div className="p-3 bg-blue-50 rounded-lg flex items-center justify-between border border-blue-200">
                    <span className="text-sm text-blue-900 font-medium">📎 {uploadedFile.name}</span>
                    <button onClick={() => setUploadedFile(null)} className="text-gray-500 hover:text-gray-700">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
                <div className="flex gap-3">
                  <Textarea
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="Type a message..."
                    rows={2}
                    className="resize-none text-sm"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && e.ctrlKey) {
                        handleSendMessage()
                      }
                    }}
                  />
                  <div className="flex flex-col gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        onChange={handleFileUpload}
                        className="hidden"
                        accept="image/*,.pdf,.doc,.docx"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-10 w-10 bg-white hover:bg-gray-50"
                      >
                        <Upload className="h-4 w-4" />
                      </Button>
                    </label>
                    <Button
                      onClick={handleSendMessage}
                      disabled={isSending || (!messageText.trim() && !uploadedFile)}
                      className="h-10 w-10 p-0"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <p>Select a user to start chatting</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
