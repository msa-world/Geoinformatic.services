"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import PasswordEye from "@/components/ui/password-eye"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useRouter } from 'next/navigation'
import { useState, useEffect } from "react"
import { AlertCircle, CheckCircle } from 'lucide-react'

const ROLE_OPTIONS = [
  { value: "Student", label: "Student" },
  { value: "GIS Analyst", label: "GIS Analyst" },
  { value: "Developer", label: "Developer" },
  { value: "Digital Marketer", label: "Digital Marketer" },
  { value: "Other", label: "Other" },
]

export default function SignUpPage() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    role: "Other",
  })
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [userExists, setUserExists] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const checkUserExists = async () => {
      if (formData.email && formData.email.includes("@")) {
        const supabase = createClient()
        try {
          const { data, error } = await supabase
            .from("profiles")
            .select("id")
            .eq("email", formData.email)
            .single()

          if (data) {
            setUserExists(true)
            setError(null)
          } else {
            setUserExists(false)
          }
        } catch (err) {
          setUserExists(false)
        }
      }
    }

    const debounce = setTimeout(checkUserExists, 500)
    return () => clearTimeout(debounce)
  }, [formData.email])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (userExists) {
      setError("This email is already registered. Please sign in instead.")
      setIsLoading(false)
      return
    }

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match")
      setIsLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters")
      setIsLoading(false)
      return
    }

    try {
      const { error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo:
            process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/auth/callback`,
          data: {
            full_name: formData.fullName,
            role: formData.role,
          },
        },
      })
      if (error) throw error
      router.push("/auth/sign-up-success")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full h-screen flex overflow-hidden">
      {/* Left side - Sign up form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-12 bg-white overflow-y-auto">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Sign up now</h1>
            <p className="text-muted">Create a free account</p>
          </div>

          {userExists && (
            <div className="flex items-start gap-3 p-3 mb-4 bg-blue-50 border border-blue-200 rounded-lg">
              <CheckCircle className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-600">
                <p className="font-semibold">Account Already Exists</p>
                <p className="mt-1">This email is already registered. <Link href="/auth/login" className="font-semibold underline hover:no-underline">Sign in here</Link> instead.</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSignUp} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-sm font-semibold">
                Full Name
              </Label>
              <Input
                id="fullName"
                name="fullName"
                type="text"
                placeholder="Full name"
                required
                value={formData.fullName}
                onChange={handleChange}
                className="h-10"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-semibold">
                Email address
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="Email address"
                required
                value={formData.email}
                onChange={handleChange}
                className="h-10"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-sm font-semibold">
                Role
              </Label>
              <select
                id="role"
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full h-10 px-3 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                disabled={isLoading}
              >
                {ROLE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-semibold">
                Password
              </Label>
              <PasswordEye
                id="password"
                name="password"
                placeholder="Password"
                required
                value={formData.password}
                onChange={(e) => setFormData((prev) => ({ ...prev, password: (e.target as HTMLInputElement).value }))}
                className="h-10 w-full"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-sm font-semibold">
                Repeat password
              </Label>
              <PasswordEye
                id="confirmPassword"
                name="confirmPassword"
                placeholder="Repeat password"
                required
                value={formData.confirmPassword}
                onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: (e.target as HTMLInputElement).value }))}
                className="h-10 w-full"
                disabled={isLoading}
              />
            </div>

            {error && !userExists && (
              <div className="flex items-start gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="h-4 w-4 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <Button type="submit" className="w-full h-10 bg-black text-white hover:bg-gray-800" disabled={isLoading || userExists}>
              {isLoading ? "Creating account..." : "Sign up"}
            </Button>

            <div className="mt-4 text-center text-sm">
              <span className="text-muted">Already have an account? </span>
              <Link href="/auth/login" className="text-primary font-semibold hover:underline">
                Sign in
              </Link>
            </div>
          </form>
        </div>
      </div>

      {/* Right side - Image section (fullscreen on larger screens) */}
      <div className="hidden lg:flex w-1/2 items-center justify-center bg-cover bg-center relative overflow-hidden" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1494783367193-149034c05e41?w=1200&q=80&fit=crop")' }}>
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative z-10 p-8 text-white text-center max-w-md">
          <h2 className="text-4xl font-bold mb-4">Bring your ideas to life.</h2>
          <p className="text-lg">Sign up for free and enjoy access to all features for 30 days. No credit card required.</p>
        </div>
      </div>
    </div>
  )
}
