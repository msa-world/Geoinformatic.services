import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Accurate Digital Data You Can Trust",
    content: [
      "Stay ahead with accurate, digitized data you can trust. Let us help you fix gaps, reduce delays, and confidently move your projects forward. Our georeferencing and digitization services transform paper maps, historical records, and analog data into precise digital formats ready for GIS analysis.",
      "We specialize in converting legacy maps, engineering drawings, aerial photographs, and satellite imagery into georeferenced digital datasets that integrate seamlessly with your existing GIS infrastructure."
    ]
  },
  {
    title: "Precision Digitization Services",
    content: [
      "Our digitization workflow combines advanced scanning technology, precise georeferencing techniques, and quality control measures to ensure that your converted data maintains spatial accuracy and attribute integrity.",
      "From simple map digitization to complex feature extraction from imagery, we handle projects of all sizes and complexities, delivering clean, topology-correct datasets that are immediately usable in your GIS applications."
    ]
  }
];

const features = [
  "Map scanning and georeferencing",
  "Vector digitization from raster sources",
  "Aerial photo and satellite image georeferencing",
  "CAD to GIS conversion",
  "Feature extraction and attribute coding",
  "Historical map digitization and restoration",
  "Quality control and topology validation",
  "Data format conversion and standardization"
];

export default function GeoreferencingDigitizationServicesPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Georeferencing & Digitization Services"
          description="Transform paper maps and analog data into accurate, georeferenced digital datasets. Fix data gaps, reduce delays, and move projects forward with confidence."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-18-1-7.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
