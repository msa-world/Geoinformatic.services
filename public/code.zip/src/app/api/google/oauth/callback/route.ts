import { NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

async function exchangeCodeForToken(code: string) {
  const tokenUrl = "https://oauth2.googleapis.com/token"
  const params = new URLSearchParams({
    code,
    client_id: process.env.GOOGLE_CLIENT_ID || "",
    client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
    redirect_uri: process.env.GOOGLE_OAUTH_REDIRECT || "",
    grant_type: "authorization_code",
  })

  const res = await fetch(tokenUrl, { method: "POST", body: params })
  const data = await res.json()
  return data
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const code = url.searchParams.get("code")
    const state = url.searchParams.get("state")
    if (!code || !state) return NextResponse.redirect(new URL("/", request.url))

    const supabase = createAdminClient()
    const { data: stateRow } = await supabase.from("oauth_states").select("user_id").eq("state", state).single()
    const userId = stateRow?.user_id
    if (!userId) return NextResponse.redirect(new URL("/", request.url))

    const tokenData = await exchangeCodeForToken(code)
    if (tokenData?.error) {
      console.error("[v0] Token exchange error", tokenData)
      return NextResponse.redirect(new URL("/", request.url))
    }

    // store refresh token and other metadata in profiles
    await supabase
      .from("profiles")
      .update({
        google_refresh_token: tokenData.refresh_token ?? null,
        google_access_token: tokenData.access_token ?? null,
        google_connected_at: new Date().toISOString(),
        google_scope: tokenData.scope ?? null,
      })
      .eq("id", userId)

    // cleanup state
    await supabase.from("oauth_states").delete().eq("state", state)

    // redirect to a confirmation page or profile
    return NextResponse.redirect(new URL("/profile?google_connected=1", request.url))
  } catch (err) {
    console.error("[v0] oauth callback error", err)
    return NextResponse.redirect(new URL("/", request.url))
  }
}
