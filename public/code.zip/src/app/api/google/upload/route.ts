import { NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

async function refreshAccessToken(refreshToken: string) {
  const tokenUrl = "https://oauth2.googleapis.com/token"
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID || "",
    client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  })

  const res = await fetch(tokenUrl, { method: "POST", body: params })
  return res.json()
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, name, mimeType, data, parentId } = body || {}
    if (!userId || !data || !name) return NextResponse.json({ success: false, message: "userId, name and data required" }, { status: 400 })

    const supabase = createAdminClient()
    const { data: profile, error } = await supabase.from("profiles").select("google_refresh_token").eq("id", userId).single()
    if (error || !profile) return NextResponse.json({ success: false, message: "Profile not found" }, { status: 404 })

    const refreshToken = profile.google_refresh_token
    if (!refreshToken) return NextResponse.json({ success: false, message: "User not connected to Google Drive" }, { status: 400 })

    const tokenResp = await refreshAccessToken(refreshToken)
    if (tokenResp.error) {
      console.error("[v0] refresh token error", tokenResp)
      return NextResponse.json({ success: false, message: "Failed to refresh token" }, { status: 500 })
    }

    const accessToken = tokenResp.access_token

    // Use FormData to build multipart request (more robust across runtimes)
  // Include parents in metadata when uploading to a specific folder
  const uploadUrl = `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,parents`

    // convert base64 to Uint8Array
    const binary = Uint8Array.from(Buffer.from(data, 'base64'))
    const blob = new Blob([binary], { type: mimeType || 'application/octet-stream' })

    const form = new FormData()
    const metadata: Record<string, any> = { name }
    if (mimeType) metadata.mimeType = mimeType
    if (parentId) metadata.parents = [parentId]
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }))
    form.append('file', blob)

    const res = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        // NOTE: Do NOT set Content-Type here; fetch will add the correct multipart boundary
      },
      body: form as unknown as BodyInit,
    })

    const json = await res.json()
    if (!res.ok) {
      console.error('[v0] drive upload error', json)
      return NextResponse.json({ success: false, message: 'Upload failed', error: json }, { status: 500 })
    }

    return NextResponse.json({ success: true, file: json })
  } catch (err) {
    console.error("[v0] google upload error", err)
    return NextResponse.json({ success: false, message: "Failed to upload file" }, { status: 500 })
  }
}
