import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Making Complex Data Useful",
    content: [
      "At Geo Informatic, our job is to make complex spatial data useful and actionable. Our mapping and spatial analysis services are built to support your specific goals and needs, transforming raw data into valuable insights that drive better decision-making.",
      "We specialize in collecting, processing, analyzing, and visualizing spatial data from multiple sources to help you understand patterns, relationships, and trends that aren't immediately obvious in traditional data formats."
    ]
  },
  {
    title: "Comprehensive Spatial Solutions",
    content: [
      "From data collection and quality control to advanced spatial modeling and visualization, we provide end-to-end spatial data services. Our team uses industry-leading GIS platforms and analytical tools to deliver accurate, timely, and relevant spatial intelligence.",
      "Whether you need demographic analysis, site suitability studies, network analysis, or custom spatial modeling, we have the expertise to turn your spatial data into a strategic asset."
    ]
  }
];

const features = [
  "Spatial data collection and validation",
  "Database design and management",
  "Advanced spatial analysis and modeling",
  "Geostatistical analysis",
  "Network and routing analysis",
  "3D spatial analysis and visualization",
  "Interactive web mapping applications",
  "Custom GIS dashboards and reporting tools"
];

export default function SpatialDataServicesPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="Spatial Data Services"
          description="Transform complex spatial data into actionable insights with our comprehensive mapping and analysis services tailored to your needs."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-13-5.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
