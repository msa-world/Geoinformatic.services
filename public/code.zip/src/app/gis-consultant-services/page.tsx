import HeaderNavigation from "@/components/sections/header-navigation";
import ServiceDetailHero from "@/components/sections/service-detail-hero";
import ServiceContent from "@/components/sections/service-content";
import Footer from "@/components/sections/footer";

const sections = [
  {
    title: "Professional GIS Consulting",
    content: [
      "Our GIS consultant services provide expert guidance and strategic planning for your geospatial projects. With a team of experienced GIS professionals and surveyors, we combine technical precision with on-ground experience and the latest geospatial technologies.",
      "We work closely with organizations across various industries to implement GIS solutions that drive better decision-making, improve operational efficiency, and unlock valuable insights from spatial data."
    ]
  },
  {
    title: "Our Approach",
    content: [
      "We begin by understanding your unique business challenges and objectives. Our consultants then design tailored GIS strategies that align with your goals, whether you're implementing a new GIS system, optimizing existing workflows, or leveraging advanced spatial analytics.",
      "Through collaborative partnerships, we ensure that your team is equipped with the knowledge and tools needed to maximize the value of your geospatial investments."
    ]
  }
];

const features = [
  "Strategic GIS planning and roadmap development",
  "System architecture design and implementation",
  "Data management and quality assurance",
  "Workflow optimization and automation",
  "Custom application development",
  "Training and capacity building",
  "Technical support and maintenance",
  "Integration with existing enterprise systems"
];

export default function GISConsultantServicesPage() {
  return (
    <div className="min-h-screen w-full">
      <HeaderNavigation />
      <main className="w-full">
        <ServiceDetailHero
          title="GIS Consultant Services"
          description="Expert GIS consulting services combining technical precision, field experience, and cutting-edge geospatial technologies to drive your projects forward."
          image="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/986c6fe2-3527-491b-b576-ae12c431a91d-geo-informatic-com/assets/images/Untitled-design-10-3.png"
        />
        <ServiceContent sections={sections} features={features} />
      </main>
      <Footer />
    </div>
  );
}
